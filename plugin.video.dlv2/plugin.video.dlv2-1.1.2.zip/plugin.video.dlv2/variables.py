import sys
import os
import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import xbmcvfs


domain = 'daddyhd.com'
base_url = f'https://{domain}'
ips = ['104.21.71.100', '172.67.144.96']
schedule_url = f'{base_url}/index.php'
schedule_url_old2 = f'{base_url}/schedule/schedule-generated.php'
channels_url = f'{base_url}/24-7-channels.php'


user_agent = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36'
headers = {
    "User-Agent": user_agent,
    "Referer": f'{base_url}/',
    "Origin": f'{base_url}/'
}

ip_headers = {
    "User-Agent": user_agent,
    "Host": domain,
    "Referer": f'{base_url}/',
    "Origin": f'{base_url}/'
}

try:
    handle = int(sys.argv[1])
except IndexError:
    handle = 0
    
plugin_url = sys.argv[0]
addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')
addon_version = addon.getAddonInfo('version')
addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
temp_path = xbmcvfs.translatePath('special://temp')
addon_name = addon.getAddonInfo('name')
addon_icon = addon.getAddonInfo('icon')
addon_fanart = addon.getAddonInfo('fanart')
get_setting = addon.getSetting
get_setting_bool = addon.getSettingBool
set_setting = addon.setSetting
end_directory = xbmcplugin.endOfDirectory


schedule_path = os.path.join(profile_path, 'schedule.json')
cat_schedule_path = os.path.join(profile_path, 'cat_schedule.json')
fav_path = os.path.join(temp_path, 'favourites.json')
fav_old_path = os.path.join(profile_path, 'favourites.json')
ch_path = os.path.join(profile_path, 'channels.json')
ch_bak_path = os.path.join(addon_path, 'resources', 'channels.json')
notify_path = os.path.join(addon_path, 'notification.txt')

set_content = xbmcplugin.setContent
set_category = xbmcplugin.setPluginCategory
set_resolved_url = xbmcplugin.setResolvedUrl
list_item = xbmcgui.ListItem
system_exit = sys.exit
execute_builtin = xbmc.executebuiltin
notify_dialog = xbmcgui.Dialog().notification
progress_dialog = xbmcgui.DialogProgress()
progress_dialogbg = xbmcgui.DialogProgressBG()
sleep = xbmc.sleep
play = xbmc.Player().play
cz_ids = {
    '1020': '692',
    '1021': '27',
    '1022': '28'
}