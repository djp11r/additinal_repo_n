import json
import time
from html.parser import unescape
import variables as var
import functions as func
from models import Item, Category, Channel, NoLink
from message import show_message
import color


def main_menu():
    func.create_listitem(NoLink(color.star_wrap(color.cyan('Welcome to Daddylive V2'))))
    
    func.create_listitem(
        Item(
            title=color.snow('Channels'),
            type='dir',
            mode='channels'
        )
    )
    
    for key in func.read_schedule():
        func.create_listitem(
            Item(
                title=color.snow(key.split(' -')[0].strip()),
                type='dir',
                mode='categories',
                title2=key
            )
        )
    
    func.create_listitem(
        Item(
            color.snow('Favourite Channels'),
            type='dir',
            mode='favourites'
        )
    )
    
    func.create_listitem(
        Item(
            color.snow('Search'),
            type='dir',
            mode='search'
        )
    )
    
    func.create_listitem(
        Item(
            color.snow('Refresh Schedule'),
            mode='refresh',
            is_media=False
        )
    )
    
    func.create_listitem(
        NoLink(
            color.snow('Notifications'),
            mode='notify'
        )
    )
    
    func.create_listitem(
        NoLink(
            color.snow('Settings'),
            mode='settings'
        )
    )

def get_channels(search_results: list=None):
    password = var.get_setting('adult_pw')
    saved_favs = func.read_favourites()
    is_search = search_results is not None
    func.create_listitem(NoLink(color.star_wrap(color.cyan('Channels'))))
    items = func.read_channels() if is_search is False else search_results
    for item in items:
        title = item['title']
        if '18+' in title and password != 'xxXXxx':
            continue
        link = item['link']
        if link not in str(saved_favs):
            cm_label = 'Add to favourite channels'
            cm_mode = 'add_fav'
        else:
            cm_label = 'Remove from favourite channels'
            cm_mode = 'remove_fav'
        cm_item = Item(
            title=title,
            mode=cm_mode,
            link=link,
            is_search=is_search
        )
        cm_url = f'{var.plugin_url}?{cm_item.url_encode()}'
        cm_url = f'RunPlugin({cm_url})'
        link = json.dumps([[title, link]])
        
        func.create_listitem(
            Channel(
                title=color.snow(title),
                link=link,
                contextmenu=[(cm_label, cm_url)],
                is_search=is_search
            )
        )

def get_categories(date):
    func.create_listitem(NoLink(color.star_wrap(color.cyan(date))))
    for key in func.read_schedule()[date].keys():
        func.create_listitem(
            Category(
                title=color.snow(key),
                title2=date,
            )
        )

def get_matches(category, date, search_results: list=None):
    is_search = search_results is not None
    schedule = func.read_schedule()[date][category] if is_search is False else search_results
    func.write_cat_schedule(json.dumps(schedule))
    func.create_listitem(NoLink(color.star_wrap(color.cyan(category))))
    for match in schedule:
        title = match['event']
        clean_title = unescape(title)
        start_time = match.get('time', '')
        try:
            clean_title = f'{color.cyan(func.convert_utc_time_to_local(start_time))}  {color.snow(clean_title)}' if start_time else color.snow(clean_title)
        except Exception as e:
            func.log(f'Error converting start time: {e}')
        
        func.create_listitem(
            Channel(
                title=clean_title,
                title2=title,
                is_search=is_search
            )
        )

def get_favourites():
    items = func.read_favourites()
    func.create_listitem(NoLink(color.star_wrap(color.cyan('Favourite Channels'))))
    for title, link in items:
        cm_label = 'Remove from favourite channels'
        cm_mode = 'remove_fav'
        cm_item = Item(
            title=title,
            mode=cm_mode,
            link=link
        )
        cm_url = f'{var.plugin_url}?{cm_item.url_encode()}'
        cm_url = f'RunPlugin({cm_url})'
        func.create_listitem(
            Channel(
                color.snow(title),
                link=json.dumps([[title, link]]),
                contextmenu=[(cm_label, cm_url)]
            )
        )

def add_favourite(title, link, is_search: bool=False):
    func.write_favourite(title, link)
    if is_search is False:
        var.execute_builtin('Container.Refresh')
    var.notify_dialog(var.addon_name, f'{title} added to favourites', icon=var.addon_icon)

def remove_favourite(title, link, is_search: bool=False):
    items = func.read_favourites()
    for item in items:
        if link in item:
            items.remove(item)
    func.write_file(var.fav_path, json.dumps(items))
    if is_search is False:
        var.execute_builtin('Container.Refresh')
    var.notify_dialog(var.addon_name, f'{title} removed from favourites', icon=var.addon_icon)

def refresh():
    var.progress_dialogbg.create(var.addon_name)
    var.progress_dialogbg.update(50, 'Refreshing schedule...')
    func.get_schedule_and_channels()
    var.progress_dialogbg.update(100, 'Refreshing schedule...Done!')
    var.sleep(500)
    var.progress_dialogbg.close()
    var.notify_dialog(var.addon_name, 'Schedule refreshed.', icon=var.addon_icon)
    func.container_refresh()

def search():
    results = func.get_search_results()
    if results:
        if results.get('events'):
            get_matches('Events', '', results['events'])
        if results.get('channels'):
            get_channels(results['channels'])

def check_new_version():
    version = var.addon_version
    saved_version = var.get_setting('version')
    if version == saved_version:
        return False
    var.set_setting('version', version)
    return True

def play_video(name: str, url: str, icon: str, description, match, is_search: bool=False):
    if match is not None:
        url = func.get_match_links(match)
    url = json.loads(url) if isinstance(url, str) else url
    if len(url) > 1:
        url = [[color.snow(title), link] for title, link in url]
        url = func.get_multilink(url)
    else:
        url = url[0][1]
    if not url:
        var.system_exit()
    
    url = func.resolve_link(url)
        
    list_item = var.list_item(name, path=url)
    
    func.set_info(list_item, {'title': name, 'plot': description})
    list_item.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
    list_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
    list_item.setMimeType('application/x-mpegURL')
    list_item.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
    if var.get_setting_bool('timeshift') is True:
        list_item.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
    list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
    var.play(url, listitem=list_item)

def notification():
    message = func.read_file(var.notify_path)
    show_message(message)

def check_refresh():
    last_refresh = float(var.get_setting('last_refresh'))
    if last_refresh == 0.0 or time.time() - (8*60*60) >= last_refresh:
        func.get_schedule_and_channels()
        var.set_setting('last_refresh', str(time.time()))

def router(params: dict):
    check_refresh()
    mode = params.get('mode')
    try:
        title = func.strip_tags(params.get('title'))
    except:
        title = params.get('title')
    title2 = params.get('title2')
    link = params.get('link', '')
    thumbnail = params.get('thumbnail')
    is_search = params.get('is_search')
    is_search = is_search in (True, 'True')
    
    if mode is None:
        if check_new_version() is True:
            notification()
        main_menu()
    
    elif mode == 'channels':
        get_channels()
    
    elif mode == 'categories':
        get_categories(title2)
    
    elif mode == 'matches':
        get_matches(title, title2)
    
    elif mode == 'favourites':
        get_favourites()
    
    elif mode == 'add_fav':
        add_favourite(title, link, is_search=is_search)
    
    elif mode == 'remove_fav':
        remove_favourite(title, link, is_search=is_search)
    
    elif mode == 'play':
        play_video(title, link, thumbnail, title, title2, is_search=is_search)
    
    elif mode == 'refresh':
        refresh()
    
    elif mode == 'search':
        search()
    
    elif mode == 'notify':
        notification()
    
    elif mode == 'settings':
        var.execute_builtin(f'Addon.OpenSettings({var.addon_id})')
    
    var.set_content(var.handle, 'videos')
    var.set_category(var.handle, title)
    var.end_directory(var.handle, cacheToDisc=False)
    