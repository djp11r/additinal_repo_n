import warnings

warnings.warn(DeprecationWarning(f'{__name__} is deprecated'))

casefold = str.casefold
