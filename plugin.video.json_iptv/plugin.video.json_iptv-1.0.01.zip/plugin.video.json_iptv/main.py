#

import os
import sys

from io import open
from urllib.parse import urlencode, parse_qsl
import xbmc, xbmcaddon, xbmcvfs, xbmcgui, xbmcplugin

_URL = sys.argv[0]
_HANDLE = int(sys.argv[1])

_transPath = xbmc.translatePath if int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0]) < 19 else xbmcvfs.translatePath
_addonInfo = xbmcaddon.Addon().getAddonInfo
_dialog = xbmcgui.Dialog()

_addonName = _addonInfo('name').replace(' ', '_').lower()
_addonIcon = _addonInfo('icon')
_addonFanart = _addonInfo('fanart')

debug_prefix = '[%s - DEBUG]' % _addonName
log_path = _transPath('special://logpath/')
log_file = os.path.join(log_path, '%s.log' % _addonName)


MENU = {
    '(About/ReadMe/Help)': [],
    'Some IPTV Channels': [
        {'title': 'Mixed List', 'url': 'mixed_list', 'image': None},
        {'title': 'Canada List', 'url': 'ca_list', 'image': None},
        {'title': 'UK List', 'url': 'uk_list', 'image': None}
    ],
    'Some Radio Providers': [
        {'title': '0nRadio Channels', 'url': '_0nRadio', 'image': None},
        {'title': '181FM Channels', 'url': '_181FM', 'image': None},
        {'title': 'BigRRadio Channels', 'url': 'BigRRadio', 'image': None},
        {'title': 'DashRadio Channels', 'url': 'DashRadio', 'image': None},
        {'title': 'GotRadio Channels', 'url': 'GotRadio', 'image': None},
        {'title': 'SomaFM Channels', 'url': 'SomaFM', 'image': None},
        {'title': 'WeAreOneFM Channels', 'url': 'WeAreOneFM', 'image': None}
    ],
    'Some IPTV Providers': [
        {'title': 'AdultSwim Channels', 'url': 'AdultSwim', 'image': None},
        {'title': 'AnthymTV Channels', 'url': 'AnthymTV', 'image': None},
        {'title': 'AvoTV Channels', 'url': 'AvoTV', 'image': None},
        {'title': 'BumbleBeeTV Channels', 'url': 'BumbleBeeTV', 'image': None},
        {'title': 'DistroTV Channels', 'url': 'DistroTV', 'image': None},
        {'title': 'FreeliTV Channels', 'url': 'FreeliTV', 'image': None},
        {'title': 'GalxyTV Channels', 'url': 'GalxyTV', 'image': None},
        {'title': 'GlewedTV Channels', 'url': 'GlewedTV', 'image': None},
        {'title': 'HerogoTV Channels', 'url': 'HerogoTV', 'image': None},
        {'title': 'ImdbTV Channels', 'url': 'ImdbTV', 'image': None},
        {'title': 'JungoPlusTV Channels', 'url': 'JungoPlusTV', 'image': None},
        {'title': 'KlowdTV Channels', 'url': 'KlowdTV', 'image': None},
        {'title': 'LocalbTV Channels', 'url': 'LocalbTV', 'image': None},
        {'title': 'LocalNow Channels', 'url': 'LocalNow', 'image': None},
        {'title': 'MuzzikTV Channels', 'url': 'MuzzikTV', 'image': None},
        {'title': 'MyTvToGo Channels', 'url': 'MyTvToGo', 'image': None},
        {'title': 'Pbs Channels', 'url': 'Pbs', 'image': None},
        {'title': 'Plex Channels', 'url': 'Plex', 'image': None},
        {'title': 'PlutoTV Channels', 'url': 'PlutoTV', 'image': None},
        {'title': 'RadTV Channels', 'url': 'RadTV', 'image': None},
        {'title': 'RedBoxTV Channels', 'url': 'RedBoxTV', 'image': None},
        {'title': 'Roku Channels', 'url': 'Roku', 'image': None},
        {'title': 'SamsungTV Channels', 'url': 'SamsungTV', 'image': None},
        {'title': 'SimulTV Channels', 'url': 'SimulTV', 'image': None},
        {'title': 'SmashPlus Channels', 'url': 'SmashPlus', 'image': None},
        {'title': 'StirrTV Channels', 'url': 'StirrTV', 'image': None},
        {'title': 'Stream4Free Channels', 'url': 'Stream4Free', 'image': None},
        {'title': 'Tcl Channels', 'url': 'Tcl', 'image': None},
        {'title': 'Tubi Channels', 'url': 'Tubi', 'image': None},
        {'title': 'TV25 Channels', 'url': 'TV25', 'image': None},
        {'title': 'VeelyTV Channels', 'url': 'VeelyTV', 'image': None},
        {'title': 'VisionTV Channels', 'url': 'VisionTV', 'image': None},
        {'title': 'VizioTV Channels', 'url': 'VizioTV', 'image': None},
        {'title': 'WatchYourTV Channels', 'url': 'WatchYourTV', 'image': None},
        {'title': 'Wfmz Channels', 'url': 'Wfmz', 'image': None},
        {'title': 'Xumo Channels', 'url': 'Xumo', 'image': None}
    ]
}


def log(msg, level=xbmc.LOGDEBUG):
    try:
        if not os.path.exists(log_file):
            f = open(log_file, 'w')
            f.close()
        with open(log_file, 'a', encoding='utf-8') as f:
            line = '%s: %s' % (debug_prefix, msg)
            f.write(line.rstrip('\r\n') + '\n')
    except Exception as e:
        xbmc.log('%s Logging Failure: %s' % (debug_prefix, e), level)
        pass


def textViewer(message, heading=_addonName):
    return _dialog.textviewer(heading, message)


def get_url(**kwargs):
    return '{}?{}'.format(_URL, urlencode(kwargs))


def get_menus():
    return MENU.keys()


def get_categories(category):
    return MENU[category]


def parse_category(url):
    if url == 'mixed_list':
        from lib.lists import mixed_list as category
    elif url == 'ca_list':
        from lib.lists import ca_list as category
    elif url == 'uk_list':
        from lib.lists import uk_list as category

    elif url == '_0nRadio':
        from lib.lists.radio import _0nRadio as category
    elif url == '_181FM':
        from lib.lists.radio import _181FM as category
    elif url == 'BigRRadio':
        from lib.lists.radio import BigRRadio as category
    elif url == 'DashRadio':
        from lib.lists.radio import DashRadio as category
    elif url == 'GotRadio':
        from lib.lists.radio import GotRadio as category
    elif url == 'SomaFM':
        from lib.lists.radio import SomaFM as category
    elif url == 'WeAreOneFM':
        from lib.lists.radio import WeAreOneFM as category

    elif url == 'AdultSwim':
        from lib.lists.providers import AdultSwim as category
    elif url == 'AnthymTV':
        from lib.lists.providers import AnthymTV as category
    elif url == 'AvoTV':
        from lib.lists.providers import AvoTV as category
    elif url == 'BumbleBeeTV':
        from lib.lists.providers import BumbleBeeTV as category
    elif url == 'DistroTV':
        from lib.lists.providers import DistroTV as category
    elif url == 'FreeliTV':
        from lib.lists.providers import FreeliTV as category
    elif url == 'GalxyTV':
        from lib.lists.providers import GalxyTV as category
    elif url == 'GlewedTV':
        from lib.lists.providers import GlewedTV as category
    elif url == 'HerogoTV':
        from lib.lists.providers import HerogoTV as category
    elif url == 'ImdbTV':
        from lib.lists.providers import ImdbTV as category
    elif url == 'JungoPlusTV':
        from lib.lists.providers import JungoPlusTV as category
    elif url == 'KlowdTV':
        from lib.lists.providers import KlowdTV as category
    elif url == 'LocalbTV':
        from lib.lists.providers import LocalbTV as category
    elif url == 'LocalNow':
        from lib.lists.providers import LocalNow as category
    elif url == 'MuzzikTV':
        from lib.lists.providers import MuzzikTV as category
    elif url == 'MyTvToGo':
        from lib.lists.providers import MyTvToGo as category
    elif url == 'Pbs':
        from lib.lists.providers import Pbs as category
    elif url == 'Plex':
        from lib.lists.providers import Plex as category
    elif url == 'PlutoTV':
        from lib.lists.providers import PlutoTV as category
    elif url == 'RadTV':
        from lib.lists.providers import RadTV as category
    elif url == 'RedBoxTV':
        from lib.lists.providers import RedBoxTV as category
    elif url == 'Roku':
        from lib.lists.providers import Roku as category
    elif url == 'SamsungTV':
        from lib.lists.providers import SamsungTV as category
    elif url == 'SimulTV':
        from lib.lists.providers import SimulTV as category
    elif url == 'SmashPlus':
        from lib.lists.providers import SmashPlus as category
    elif url == 'StirrTV':
        from lib.lists.providers import StirrTV as category
    elif url == 'Stream4Free':
        from lib.lists.providers import Stream4Free as category
    elif url == 'Tcl':
        from lib.lists.providers import Tcl as category
    elif url == 'Tubi':
        from lib.lists.providers import Tubi as category
    elif url == 'TV25':
        from lib.lists.providers import TV25 as category
    elif url == 'VeelyTV':
        from lib.lists.providers import VeelyTV as category
    elif url == 'VisionTV':
        from lib.lists.providers import VisionTV as category
    elif url == 'VizioTV':
        from lib.lists.providers import VizioTV as category
    elif url == 'WatchYourTV':
        from lib.lists.providers import WatchYourTV as category
    elif url == 'Wfmz':
        from lib.lists.providers import Wfmz as category
    elif url == 'Xumo':
        from lib.lists.providers import Xumo as category

    return category.channels


def list_menu():
    xbmcplugin.setPluginCategory(_HANDLE, 'Json IPTV')
    xbmcplugin.setContent(_HANDLE, 'addons')
    items = get_menus()
    for item in items:
        list_item = xbmcgui.ListItem(label=item)
        list_item.setInfo('video', {'title': item, 'mediatype': 'video'})
        artwork = _addonIcon if item == '(About/ReadMe/Help)' else None
        list_item.setArt({'thumb': artwork, 'icon': artwork, 'fanart': _addonFanart})
        url = get_url(action='listing1', category=item)
        is_folder = True
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_HANDLE)


def list_categories(category):
    if category == '(About/ReadMe/Help)':
        _message = 'This IPTV Addon is untested and user input based, meaning i dont know what works or doesnt work unless you tell me. [CR]' \
            'Feel free to contact me about anything and if reporting info on these sections try to include enough info like... [CR]' \
            'Channel Menu Name, Channel Name, Your Location, and your problem. [CR]' \
            'I will update the lists of channels with modified titles to show user based info like "(Maybe Broken)" or maybe new found working urls if i can lol. [CR]' \
            'Note that contacting me about IPTV related stuff like this is best done with emails. ContactMe: jewbmx@gmail.com'
        return textViewer(_message)
    else:
        xbmcplugin.setPluginCategory(_HANDLE, category)
        xbmcplugin.setContent(_HANDLE, 'addons')
        items = get_categories(category)
        for item in items:
            list_item = xbmcgui.ListItem(label=item['title'])
            list_item.setInfo('video', {'title': item['title'], 'mediatype': 'video'})
            artwork = item['image'] if not item['image'] == (None or 'None') else 'DefaultVideo.png'
            list_item.setArt({'thumb': artwork, 'icon': artwork, 'fanart': _addonFanart})
            url = get_url(action='listing2', category=item['url'])
            is_folder = True
            xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
        #xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.endOfDirectory(_HANDLE)


def list_videos(category):
    xbmcplugin.setPluginCategory(_HANDLE, category)
    xbmcplugin.setContent(_HANDLE, 'addons')
    items = parse_category(category)
    #test_list = []
    for item in items:
        #try:
            #if item['url'] in str(test_list):
                #log('DupeTest possible dupe: \n' + repr(item['url']))
            #else:
                #test_list.append(item)
        #except:
            #pass
        list_item = xbmcgui.ListItem(label=item['title'])
        list_item.setInfo('video', {'title': item['title'], 'mediatype': 'video'})
        artwork = item['image'] if not item['image'] == (None or 'None') else 'DefaultVideo.png'
        list_item.setArt({'thumb': artwork, 'icon': artwork, 'fanart': _addonFanart})
        list_item.setProperty('IsPlayable', 'true')
        url = get_url(action='play', url=item['url'])
        is_folder = False
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    #xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_HANDLE)


def play_video(path):
    play_item = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=play_item)


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if params['action'] == 'listing1':
            list_categories(params['category'])
        elif params['action'] == 'listing2':
            list_videos(params['category'])
        elif params['action'] == 'play':
            play_video(params['url'])
        else:
            raise ValueError('Invalid paramstring: {}!'.format(paramstring))
    else:
        list_menu()


if __name__ == '__main__':
    router(sys.argv[2][1:])


