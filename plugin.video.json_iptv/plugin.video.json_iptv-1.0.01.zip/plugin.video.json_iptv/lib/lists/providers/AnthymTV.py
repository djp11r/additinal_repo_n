
channels = [


    {"title": "Americanna Channel", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/Classics/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/t4XtyGI.jpg"},
    {"title": "AnthymTV", "url": "https://2evn4djdndpz-hls-push.5centscdn.com/raw/About%20AnthymTV%20(11_24)%20-%20HD%201080p_MULTI.mp4/playlist.m3u8", "image": "https://i.imgur.com/VEDobKB.png"},
    {"title": "Comedy", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/SNL/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/zAH9qRD.jpg"},
    {"title": "Cops", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/LivePD/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/ED2jB5z.jpg"},
    {"title": "Discover", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/Discover/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/Cpg9AYp.png"},
    {"title": "Fight Night", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/Fight/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/USzBsCd.png"},
    {"title": "Food", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/FOOD/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/IHgME4F.png"},
    {"title": "Game Show", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/GAMESHOW/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/heYzuQZ.jpg"},
    {"title": "Gear Head", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/Chassy/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/4KhV9tG.jpg"},
    {"title": "History", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/HISTORY/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/mucRmPt.jpg"},
    {"title": "Holiday Yule Log", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/TEST/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/YhAVLYs.png"},
    {"title": "Holiday", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/ROTATING/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/YhAVLYs.png"},
    {"title": "Hollywood", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/POP/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/8ox1SxY.jpg"},
    {"title": "Home", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/House/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/DhE0LBk.jpg"},
    {"title": "Jerry", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/JERRY/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/bOXE0EP.jpg"},
    {"title": "Lifestyle", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/TLC/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/XQavC8G.jpg"},
    {"title": "Outdoors", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/Outdoors/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/YcFIFqn.jpg"},
    {"title": "Pawn", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/PawnStars/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/MkOnIBs.jpg"},
    {"title": "Politics", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/Politics/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/8ox1SxY.jpg"},
    {"title": "Reality Cable Hits", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/AETV/514c04b31b5f01cf00dd4965e197fdda.sdp/playlist.m3u8", "image": "https://i.imgur.com/Ciiek5O.jpg"},
    {"title": "SportTalk", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/SportsCenter/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/0x2qkjJ.png"},
    {"title": "Star", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/Star/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/IWxnZgg.png"},
    {"title": "Swamp Folk", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/Duck/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/dB5G44K.jpg"},
    {"title": "Travel", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/TRAVEL/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/FLlIbah.jpg"},
    {"title": "True Crime", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/CRIME/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/HkekVpX.jpg"},
    {"title": "TV Guide", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/Cranium/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/rmvtYnZ.png"},
    {"title": "WallStreet", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/BUSINESS/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/cDrQF55.jpg"},
    {"title": "Wild West", "url": "https://bk7l2w4nlx53-hls-live.5centscdn.com/WildWest/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8", "image": "https://i.imgur.com/LLwg86e.jpg"},


]


