
channels = [


    {"title": "80'SPIRIT", "url": "https://muzzik-live.morescreens.com/mts-7-ao/playlist.m3u8", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "90'SPIRIT", "url": "https://muzzik-live.morescreens.com/mts-2-ao/playlist.m3u8", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "Adria", "url": "https://prd-icecast.spectar.tv:8000/adria", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "Blues", "url": "https://prd-icecast.spectar.tv:8443/blues", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "Cafe & Club", "url": "https://prd-icecast.spectar.tv:8443/cafeclub", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "Electro", "url": "https://prd-icecast.spectar.tv:8443/electro", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "Flash Back", "url": "http://muzzik-live.morescreens.com/mts-8/playlist.m3u8", "image": "https://i.imgur.com/w3VTnTQ.png"},
    {"title": "HardRock", "url": "https://prd-icecast.spectar.tv:8443/hardrock", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "Jeka", "url": "http://muzzik-live.morescreens.com/mts-4/playlist.m3u8", "image": "https://i.imgur.com/w3VTnTQ.png"},
    {"title": "Jeka", "url": "https://prd-icecast.spectar.tv:8443/jeka", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "Kafana", "url": "https://prd-icecast.spectar.tv:8443/kafana", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "Muzzik HipHop", "url": "http://muzzik-live.morescreens.com/mts-a4/playlist.m3u8", "image": "https://i.imgur.com/w3VTnTQ.png"},
    {"title": "Muzzik Replay", "url": "http://muzzik-live.morescreens.com/mts-a3/playlist.m3u8", "image": "https://i.imgur.com/w3VTnTQ.png"},
    {"title": "Muzzik Saculatac", "url": "http://muzzik-live.morescreens.com/mts-a2/playlist.m3u8", "image": "https://i.imgur.com/w3VTnTQ.png"},
    {"title": "Muzzik TV", "url": "http://muzzik-live.morescreens.com/mts-6/playlist.m3u8", "image": "https://i.imgur.com/w3VTnTQ.png"},
    {"title": "Muzzik", "url": "https://muzzik-live.morescreens.com/mts-6-ao/playlist.m3u8", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "OKK", "url": "http://muzzik-live.morescreens.com/mts-2/playlist.m3u8", "image": "https://i.imgur.com/w3VTnTQ.png"},
    {"title": "Pop Star", "url": "http://muzzik-live.morescreens.com/mts-3/playlist.m3u8", "image": "https://i.imgur.com/w3VTnTQ.png"},
    {"title": "Pop Star", "url": "https://muzzik-live.morescreens.com/mts-3-ao/playlist.m3u8", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "Progress", "url": "https://prd-icecast.spectar.tv:8443/progress", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "Riviera", "url": "http://muzzik-live.morescreens.com/mts-a5/playlist.m3u8", "image": "https://i.imgur.com/w3VTnTQ.png"},
    {"title": "Riviera", "url": "https://prd-icecast.spectar.tv:8443/riviera", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "Rock & Roll", "url": "http://muzzik-live.morescreens.com/mts-1/playlist.m3u8", "image": "https://i.imgur.com/w3VTnTQ.png"},
    {"title": "Rock", "url": "https://muzzik-live.morescreens.com/mts-1-ao/playlist.m3u8", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "Sach", "url": "https://prd-icecast.spectar.tv:8443/sach", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "Sense", "url": "http://muzzik-live.morescreens.com/mts-7/playlist.m3u8", "image": "https://i.imgur.com/w3VTnTQ.png"},
    {"title": "Sense", "url": "https://prd-icecast.spectar.tv:8443/sense", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "Soul", "url": "https://prd-icecast.spectar.tv:8443/soul", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "Tre X", "url": "https://muzzik-live.morescreens.com/mts-8-ao/playlist.m3u8", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "WWM", "url": "http://muzzik-live.morescreens.com/mts-5/playlist.m3u8", "image": "https://i.imgur.com/w3VTnTQ.png"},
    {"title": "WWM", "url": "https://muzzik-live.morescreens.com/mts-5-ao/playlist.m3u8", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "YuWave", "url": "https://prd-icecast.spectar.tv:8443/yuwave", "image": "https://i.imgur.com/NyJV2oL.png"},
    {"title": "ZZ TV", "url": "https://muzzik-live.morescreens.com/mts-a4-ao/playlist.m3u8", "image": "https://i.imgur.com/NyJV2oL.png"},


]


