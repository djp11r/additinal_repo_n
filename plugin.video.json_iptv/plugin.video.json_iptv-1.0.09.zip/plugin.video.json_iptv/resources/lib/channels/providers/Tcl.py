
channels = [


    {"title": "Bloody Disgusting", "url": "https://bloodydisgusting-tcl.amagi.tv/playlist.m3u8", "image": "None"},
    {"title": "Comedy Dynamics", "url": "https://comedydynamics-tcl.amagi.tv/playlist.m3u8", "image": "None"},
    {"title": "CONtv Anime", "url": "https://contvanime-tcl.amagi.tv/playlist.m3u8", "image": "None"},
    {"title": "CONtv", "url": "https://contv-tcl.amagi.tv/playlist.m3u8", "image": "None"},
    {"title": "Docurama", "url": "https://docurama-tcl.amagi.tv/playlist.m3u8", "image": "None"},
    {"title": "Dove Channel", "url": "https://dovenow-tcl.amagi.tv/playlist.m3u8", "image": "None"},
    {"title": "InTrouble", "url": "https://introuble-tcl.amagi.tv/playlist.m3u8", "image": "None"},
    {"title": "InWonder", "url": "https://inwonder-tcl.amagi.tv/playlist.m3u8", "image": "None"},
    {"title": "Latido Music", "url": "https://vidaprimo-tcl.amagi.tv/playlist.m3u8", "image": "None"},
    {"title": "MyTime Movie Network", "url": "https://mytime-tcl.amagi.tv/playlist.m3u8", "image": "None"},
    {"title": "So Real", "url": "https://soreal-tcl.amagi.tv/playlist.m3u8", "image": "None"},
    {"title": "Unbeaten", "url": "https://unbeaten-tcl.amagi.tv/playlist.m3u8", "image": "None"},
    {"title": "Whistle Sports", "url": "https://whistlesports-tcl.amagi.tv/playlist.m3u8", "image": "None"},
    {"title": "Young Hollywood", "url": "https://younghollywood-tcl.amagi.tv/playlist.m3u8", "image": "None"},


]


