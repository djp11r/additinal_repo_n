# -*- coding: utf-8 -*-

from resources.lib.modules import directory as lets


class main_menu:
    def root(self):
        lets.addDirectoryItem('Json IPTV Menu', 'json_iptv_menu', None)
        lets.addDirectoryItem('Site IPTV Menu', 'site_iptv_menu', None)
        lets.addDirectoryItem('Site Music Menu', 'site_music_menu', None)
        lets.addDirectoryItem('Personal Menu', 'personal_menu', None)
        lets.addDirectoryItem('Tools Menu', 'tools_menu', 'DefaultAddonService.png')
        lets.endDirectory()


    def site_iptv_menu(self):
        lets.addDirectoryItem('Toonami Aftermath TV', 'toonamiaftermath_menu', None)
        lets.addDirectoryItem('WatchYourTV', 'watchyourtv_menu', None)
        lets.endDirectory()


    def site_music_menu(self):
        lets.addDirectoryItem('NightRide: StreamSafe Songs', 'nightride_streamsafe_menu', None)
        lets.addDirectoryItem('NightRide: Stations', 'nightride_stations_menu', None)
        lets.endDirectory()


    def personal_menu(self):
        lets.addDirectoryItem('Personal Lists', 'personal_lists_menu', None)
        lets.addDirectoryItem('Personal Channels', 'personal_channels_menu', None)
        lets.endDirectory()


    def tools(self):
        lets.addDirectoryItem('(About/ReadMe/Help)', 'view_information', 'DefaultIconInfo.png', isFolder=False)
        lets.addDirectoryItem('Open Settings', 'open_settings&query=0.0', 'DefaultAddonProgram.png', isFolder=False)
        lets.addDirectoryItem('View ChangeLog', 'view_changelog', 'DefaultAddonProgram.png', isFolder=False)
        lets.addDirectoryItem('View DebugLog', 'view_debuglog', 'DefaultAddonProgram.png', isFolder=False)
        lets.addDirectoryItem('Empty DebugLog', 'empty_debuglog', 'DefaultAddonProgram.png', isFolder=False)
        lets.endDirectory()


