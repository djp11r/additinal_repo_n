
channels = [


    {"title": "American Classic Entertainement", "url": "https://cdn.igocast.com/channel3_hls/channel3_profile1.m3u8", "image": "https://i.imgur.com/y3SGuRQ.png"},
    {"title": "Buzzr", "url": "https://cdn.igocast.com/channel1_hls/channel1_profile1.m3u8", "image": "https://i.imgur.com/S3lUDTL.jpg"},
    {"title": "JTV", "url": "https://cdn.igocast.com/channel12_hls/channel12_profile1.m3u8", "image": "https://i.imgur.com/SwYmn98.jpg"},
    {"title": "NewsNet", "url": "https://cdn.igocast.com/channel2_hls/channel2_profile1.m3u8", "image": "https://i.imgur.com/FFdGPvn.jpg"},
    {"title": "Real America Voice", "url": "https://cdn.igocast.com/channel5_hls/channel5_profile1.m3u8", "image": "https://i.imgur.com/YipmJmc.png"},
    {"title": "RetroTV", "url": "https://cdn.igocast.com/channel9_hls/channel9_profile1.m3u8", "image": "https://i.imgur.com/0fNh0ua.jpg"},
    {"title": "REV'N", "url": "https://cdn.igocast.com/channel7_hls/channel7_profile1.m3u8", "image": "https://i.imgur.com/OGbtRMJ.jpg"},
    {"title": "ShopLC", "url": "https://cdn.igocast.com/channel10_hls/channel10_profile1.m3u8", "image": "https://i.imgur.com/VWuy4xo.jpg"},
    {"title": "The Action Channel", "url": "https://cdn.igocast.com/channel4_hls/channel4_profile1.m3u8", "image": "https://i.imgur.com/BpnJ8jQ.jpg"},
    {"title": "The Grio", "url": "https://cdn.igocast.com/channel8_hls/channel8_profile1.m3u8", "image": "https://i.imgur.com/jKFTvZL.jpg"},
    {"title": "This", "url": "https://cdn.igocast.com/channel11_hls/channel11_profile1.m3u8", "image": "https://i.imgur.com/4VCfM5r.jpg"},
    {"title": "WeatherNationTV", "url": "https://cdn.igocast.com/channel6_hls/channel6_profile1.m3u8", "image": "https://i.imgur.com/e8UgZFx.jpg"},


]


