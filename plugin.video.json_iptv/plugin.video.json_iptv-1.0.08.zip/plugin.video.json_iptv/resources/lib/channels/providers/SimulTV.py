
channels = [


    {"title": "2A Network", "url": "https://simultv.s.llnwi.net/n4s4/2ANetwork/interlink.m3u8", "image": "None"},
    {"title": "Cowboy Theater", "url": "https://simultv.s.llnwi.net/o054/CowboyTheater/interlink.m3u8", "image": "None"},
    {"title": "Cut Up N Cook", "url": "https://simultv.s.llnwi.net/n4s4/CutUpNCook/interlink.m3u8", "image": "None"},
    {"title": "Dimensions", "url": "https://simultv.s.llnwi.net/o054/Dimensions/interlink.m3u8", "image": "None"},
    {"title": "Funnybone", "url": "https://simultv.s.llnwi.net/o054/FunnyBone/interlink.m3u8", "image": "None"},
    {"title": "Kartoon Circus", "url": "https://simultv.s.llnwi.net/n4s4/KartoonCircus/interlink.m3u8", "image": "None"},
    {"title": "Kartoon Circus", "url": "https://simultv.s.llnwi.net/o062/KartoonCircus/interlink.m3u8", "image": "None"},
    {"title": "Kid Central", "url": "https://simultv.s.llnwi.net/o058/KidCentral/interlink.m3u8", "image": "None"},
    {"title": "Lifestyle", "url": "https://simultv.s.llnwi.net/o058/Lifestyle/interlink.m3u8", "image": "None"},
    {"title": "Military Home Life", "url": "https://simultv.s.llnwi.net/n4s4/MilitaryHomeLife/interlink.m3u8", "image": "None"},
    {"title": "Mythos", "url": "https://simultv.s.llnwi.net/o058/Mythos/interlink.m3u8", "image": "None"},
    {"title": "Prime Time Drama", "url": "https://simultv.s.llnwi.net/o064/PrimeTimeDrama/interlink.m3u8", "image": "None"},
    {"title": "Providence Christian Network", "url": "https://simultv.s.llnwi.net/n4s4/ProvidenceNetwork/interlink.m3u8", "image": "None"},
    {"title": "Ready Set Action", "url": "https://simultv.s.llnwi.net/o059/ReadySetAction/interlink.m3u8", "image": "None"},
    {"title": "SimSi TV", "url": "https://simultv.s.llnwi.net/o060/SimSiTV/interlink.m3u8", "image": "None"},
    {"title": "Slap Tech", "url": "https://simultv.s.llnwi.net/o061/SlapTech/interlink.m3u8", "image": "None"},
    {"title": "Spydar TV", "url": "https://simultv.s.llnwi.net/n4s4/Spydar/interlink.m3u8", "image": "None"},
    {"title": "Spydar", "url": "https://simultv.s.llnwi.net/o062/Spydar/interlink.m3u8", "image": "None"},
    {"title": "Switch", "url": "https://simultv.s.llnwi.net/o062/Switch/interlink.m3u8", "image": "None"},
    {"title": "Xcorps", "url": "https://simultv.s.llnwi.net/n4s4/xcorps/interlink.m3u8", "image": "None"},
    {"title": "XZone", "url": "https://simultv.s.llnwi.net/o060/xzone/interlink.m3u8", "image": "None"},


]


