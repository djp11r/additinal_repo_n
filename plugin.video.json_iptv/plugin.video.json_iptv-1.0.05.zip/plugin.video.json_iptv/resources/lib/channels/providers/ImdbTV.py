
channels = [


    {"title": "Absolute Reality by WE TV", "url": "https://amc-absolutereality-1.imdbtv.wurl.com/manifest/playlist.m3u8", "image": "None"},
    {"title": "AMC Presents", "url": "https://amc-amcpresents-1.imdbtv.wurl.com/manifest/playlist.m3u8", "image": "None"},
    {"title": "IFC Films Picks", "url": "https://amc-ifc-films-picks-1.imdbtv.wurl.com/manifest/playlist.m3u8", "image": "None"},
    {"title": "Rush by AMC", "url": "https://amc-rushbyamc-1.imdbtv.wurl.com/manifest/playlist.m3u8", "image": "None"},
    {"title": "Slightly Off by IFC", "url": "https://amc-slightly-off-by-amc-1.imdbtv.wurl.com/manifest/playlist.m3u8", "image": "None"},


]


