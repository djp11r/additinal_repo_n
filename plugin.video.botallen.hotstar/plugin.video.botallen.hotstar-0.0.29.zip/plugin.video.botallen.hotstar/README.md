<h2 align="center">
  <br>
  <a href="https://github.com/botallen/repository.botallen/tree/master/plugin.video.botallen.hotstar"><img src="resources/icon.jpg" height="60" width="60"></a>
  <br>
  Disney+ Hotstar
  <br>
</h2>

<h4 align="center">Disney+ Hotstar Kodi Add-on</h4>

<br>

## Disclaimer

This plugin is not officially commissioned/supported by Hotstar. The trademark "Hotstar" is registered by "Novi Digital Entertainment Private Limited (Novi)"
