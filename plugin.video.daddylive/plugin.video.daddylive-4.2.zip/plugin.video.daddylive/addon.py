# -*- coding: utf-8 -*-

import re
import sys
import json
import html
from urllib.parse import urlencode, quote, unquote, parse_qsl
from datetime import datetime, timedelta, timezone
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

addon_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.daddylive')

mode = addon.getSetting('mode')
baseurl = addon.getSetting('current_url')
json_url = '{}/stream/stream-{}.php'.format(baseurl, '%s')
schedule_url = baseurl + '/schedule/schedule-generated.json'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0'
FANART = addon.getAddonInfo('fanart')
ICON = addon.getAddonInfo('icon')
debug = addon.getSetting('debug') == "true"

def log(msg):
    if debug: xbmc.log(f'dlhd debug: {msg}', xbmc.LOGINFO)

def get_timezone_offset_minutes():
    millis = 1288483950000
    ts = millis * 1e-3
    utc_offset = datetime.fromtimestamp(ts) - datetime.utcfromtimestamp(ts)
    timezone_offset_minutes = utc_offset / timedelta(minutes=1)
    log(f'utc_offset: {utc_offset} timezone_offset_minutes: {timezone_offset_minutes}')
    return timezone_offset_minutes

def get_local_time(utc_time_str):
    timezone_offset_minutes = get_timezone_offset_minutes()
    event_time_utc = datetime.strptime(utc_time_str, '%H:%M')
    event_time_local = event_time_utc + timedelta(minutes=timezone_offset_minutes)
    local_time_str = event_time_local.strftime('%I:%M %p ET').lstrip('0')
    return local_time_str


def build_url(query):
    return addon_url + '?' + urlencode(query)


def addDir(title, dir_url, is_folder=True):
    title = str(title)
    item = xbmcgui.ListItem(title, offscreen=True)
    info_tag = item.getVideoInfoTag()
    info_tag.setMediaType('video')
    info_tag.setTitle(title)
    info_tag.setPlot('Daddylive')
    item.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': ICON, 'fanart': FANART})
    if is_folder is True: item.setProperty("IsPlayable", 'false')
    else: item.setProperty("IsPlayable", 'true')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=dir_url, listitem=item, isFolder=is_folder)


def closeDir():
    xbmcplugin.endOfDirectory(addon_handle)


def Main_Menu():
    menu = [['LIVE SPORTS', 'sched'], ['LIVE TV', 'live_tv'],]
    for m in menu:
        addDir(m[0], build_url({'mode': 'menu', 'serv_type': m[1]}))
    closeDir()


def getCategTrans():
    hea = {'User-Agent': UA}
    categs = []
    try:
        schedule = requests.get(schedule_url, headers=hea, timeout=10).json()
        for date_key, events in schedule.items():
            for categ, events_list in events.items():
                categs.append((categ, json.dumps(events_list)))
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error fetching category data: {e}")
        return []

    return categs


def Menu_Trans():
    categs = getCategTrans()
    if not categs: return
    for categ_name, events_list in categs:
        addDir(categ_name, build_url({'mode': 'showChannels', 'trType': categ_name}))
    closeDir()


def ShowChannels(categ, channels_list):
    for item in channels_list:
        addDir(item.get('title'), build_url({'mode': 'trList', 'trType': categ, 'channels': json.dumps(item.get('channels'))}), True)
    closeDir()


def getTransData(categ):
    trns = []
    categs = getCategTrans()
    for categ_name, events_list_json in categs:
        if categ_name == categ:
            events_list = json.loads(events_list_json)
            for item in events_list:
                event = item.get('event')
                time_str = item.get('time')
                event_time_local = get_local_time(time_str)
                title = f'{event_time_local} {event}'
                channels = item.get('channels')
                trns.append({
                    'title': title,
                    'channels': [{'channel_name': channel.get('channel_name'), 'channel_id': channel.get('channel_id')} for channel in channels]
                })
    return trns


def TransList(categ, channels):
    for channel in channels:
        channel_title = html.unescape(channel.get('channel_name'))
        channel_id = channel.get('channel_id')
        addDir(channel_title, build_url({'mode': 'trLinks', 'trData': json.dumps({'channels': [{'channel_name': channel_title, 'channel_id': channel_id}]})}), False)
    closeDir()


def getSource(trData):
    data = json.loads(unquote(trData))
    channels_data = data.get('channels')
    if channels_data is not None and isinstance(channels_data, list):
        url_stream = f'{baseurl}/stream/stream-{channels_data[0]["channel_id"]}.php'
        xbmcplugin.setContent(addon_handle, 'videos')
        PlayStream(url_stream)
    else:
        log('[Daddylive] Error in getting source: Invalid or missing channel data')
        xbmcgui.Dialog().ok('Error', 'Error getting source: Invalid or missing channel data')


def list_gen():
    chData = channels()
    for c in chData:
        addDir(c[1], build_url({'mode': 'play', 'url': baseurl + '/' + c[0]}), False)
    closeDir()


def channels():
    url = baseurl + '/24-7-channels.php'
    do_adult = xbmcaddon.Addon().getSetting('adult_pw')
    hea = {'Referer': baseurl + '/', 'user-agent': UA,}
    resp = requests.post(url, headers=hea).text
    ch_block = re.compile('<center><h1(.+?)tab-2', re.MULTILINE | re.DOTALL).findall(str(resp))
    chan_data = re.compile('href=\"(.*)\" target(.*)<strong>(.*)</strong>').findall(ch_block[0])
    channels = []
    for c in chan_data:
        if not '18+' in c[2]:
            channels.append([c[0], c[2]])
        if do_adult == 'lol' and '18+' in c[2]:
            channels.append([c[0], c[2]])
    return channels


def PlayStream(url):

    hea = {'Referer': baseurl + '/', 'user-agent': UA, }
    log(f"url: {url}\nhea: {hea}")
    resp = requests.post(url, headers=hea).text
    # log(f'resp: {resp}')
    url_1 = re.compile('iframe src="(.*)" width').findall(resp)[0]
    hea = {'Referer': url, 'user-agent': UA, }
    log(f'url_1: {url_1}\nhea: {hea}')
    resp = requests.post(url_1, headers=hea).text
    # log(f'resp: {resp}')
    stream = re.compile('source:\'(.*)\'').findall(resp)
    log(f'stream: {stream}')
    links = [x for x in stream if 'm3u8?auth=' in x]
    if len(links) > 1:
        dialog = xbmcgui.Dialog()
        ret = dialog.select('Choose Stream', stream)
        # log(f'ret: {ret}')
        link = stream[ret]
    else: link = links[0]
    log(f'link: {link}')
    if link:
        hdr = 'Referer=' + quote(str(url_1)) + '&User-Agent=' + UA
        play_item = xbmcgui.ListItem(path=link + '|' + hdr)

        if addon.getSetting('inputstream') == 'true':
            import inputstreamhelper
            PROTOCOL = 'hls'
            is_helper = inputstreamhelper.Helper(PROTOCOL)
            if is_helper.check_inputstream():
                play_item.setMimeType('application/x-mpegurl')
                play_item.setContentLookup(False)
                if sys.version_info >= (3, 0, 0): play_item.setProperty('inputstream', is_helper.inputstream_addon)
                else: play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)
                play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
                play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
                play_item.setProperty('IsPlayable', 'true')
                play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)


mode = params.get('mode', None)

if not mode:
    Main_Menu()
else:
    log(f"params: {params}")
    if mode == 'menu':
        servType = params.get('serv_type')
        if servType == 'sched':
            Menu_Trans()
        if servType == 'live_tv':
            list_gen()

    if mode == 'showChannels':
        transType = params.get('trType')
        channels = getTransData(transType)
        ShowChannels(transType, channels)

    if mode == 'trList':
        transType = params.get('trType')
        channels = json.loads(params.get('channels'))
        TransList(transType, channels)

    if mode == 'trLinks':
        trData = params.get('trData')
        getSource(trData)

    if mode == 'play':
        link = params.get('url')
        PlayStream(link)