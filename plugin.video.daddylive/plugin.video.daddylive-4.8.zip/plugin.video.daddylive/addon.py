# -*- coding: utf-8 -*-

import re
import sys
import json
import html
import time

from urllib.parse import urlencode, quote, unquote, parse_qsl, quote_plus, urlparse
from datetime import datetime, timedelta, timezone
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import base64

addon_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.daddylive')

mode = addon.getSetting('mode')
baseurl = addon.getSetting('current_url')
json_url = f'{baseurl}/stream/stream-%s.php'
schedule_url = baseurl + '/schedule/schedule-generated.json'
UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
FANART = addon.getAddonInfo('fanart')
ICON = addon.getAddonInfo('icon')
debug = addon.getSetting('debug') == "true"

def log(msg):
    if debug: xbmc.log(f'dlhd debug: {msg}', xbmc.LOGINFO)

def get_timezone_offset_minutes():
    millis = 1288483950000
    ts = millis * 1e-3
    utc_offset = datetime.fromtimestamp(ts) - datetime.utcfromtimestamp(ts)
    timezone_offset_minutes = utc_offset / timedelta(minutes=1)
    log(f'utc_offset: {utc_offset} timezone_offset_minutes: {timezone_offset_minutes}')
    return timezone_offset_minutes

def get_local_time(utc_time_str):
    timezone_offset_minutes = get_timezone_offset_minutes()
    log(f'utc_time_str: {utc_time_str} timezone_offset_minutes: {timezone_offset_minutes}')
    try: event_time_utc = datetime.strptime(utc_time_str, '%H:%M')
    except TypeError: event_time_utc = datetime(*(time.strptime(utc_time_str, '%H:%M')[0:6]))
    #timezone_offset_minutes = -300
    event_time_local = event_time_utc + timedelta(minutes=timezone_offset_minutes)
    local_time_str = event_time_local.strftime('%I:%M %p').lstrip('0')
    return local_time_str



def make_session(url=baseurl):
	session = requests.Session()
	retries = requests.adapters.Retry(total=3, backoff_factor=0.3, status_forcelist=(429, 500, 502, 503, 504, 520, 521, 522, 524, 530))
	session.mount(url, requests.adapters.HTTPAdapter(max_retries=retries, pool_maxsize=100))
	return session


session = make_session()


def build_url(query):
    return addon_url + '?' + urlencode(query)


def addDir(title, dir_url, is_folder=True):
    title = str(title)
    item = xbmcgui.ListItem(title, offscreen=True)
    infotag = item.getVideoInfoTag()
    infotag.setMediaType('video')
    infotag.setTitle(title)
    infotag.setPlot('Daddylive')
    item.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': ICON, 'fanart': FANART})
    if is_folder is True: item.setProperty("IsPlayable", 'false')
    else: item.setProperty("IsPlayable", 'true')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=dir_url, listitem=item, isFolder=is_folder)


def closeDir():
    xbmcplugin.endOfDirectory(addon_handle)


def Main_Menu():
    menu = [['LIVE SPORTS', 'sched'], ['LIVE TV', 'live_tv'],]
    for m in menu:
        addDir(m[0], build_url({'mode': 'menu', 'serv_type': m[1]}))
    closeDir()


def getCategTrans():
    hea = {'User-Agent': UA}
    categs = []
    try:
        schedule = session.get(schedule_url, headers=hea, timeout=10).json()
        for date_key, events in schedule.items():
            for categ, events_list in events.items():
                categs.append((categ, json.dumps(events_list)))
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error fetching category data: {e}")
        return []

    return categs


def Menu_Trans():
    categs = getCategTrans()
    if not categs: return
    for categ_name, events_list in categs:
        addDir(categ_name, build_url({'mode': 'showChannels', 'trType': categ_name}))
    closeDir()


def ShowChannels(categ, channels_list):
    for item in channels_list:
        addDir(item.get('title'), build_url({'mode': 'trList', 'trType': categ, 'channels': json.dumps(item.get('channels'))}), True)
    closeDir()


def getTransData(categ):
    trns = []
    categs = getCategTrans()
    for categ_name, events_list_json in categs:
        if categ_name == categ:
            events_list = json.loads(events_list_json)
            for item in events_list:
                event = item.get('event')
                time_str = item.get('time')
                event_time_local = get_local_time(time_str)
                title = f'{event_time_local} {event}'
                channels = item.get('channels')
                if isinstance(channels, list) and all(isinstance(channel, dict) for channel in channels):
                    trns.append({
                        'title': title,
                        'channels': [{'channel_name': channel.get('channel_name'), 'channel_id': channel.get('channel_id')} for channel in channels]
                    })
                else: log(f"Unexpected data structure in 'channels': {channels}")
    return trns


def TransList(categ, channels):
    for channel in channels:
        channel_title = html.unescape(channel.get('channel_name'))
        channel_id = channel.get('channel_id')
        addDir(channel_title, build_url({'mode': 'trLinks', 'trData': json.dumps({'channels': [{'channel_name': channel_title, 'channel_id': channel_id}]})}), False)
    closeDir()


def getSource(trData):
    data = json.loads(unquote(trData))
    channels_data = data.get('channels')
    if channels_data is not None and isinstance(channels_data, list):
        url_stream = f'{baseurl}/stream/stream-{channels_data[0]["channel_id"]}.php'
        xbmcplugin.setContent(addon_handle, 'videos')
        PlayStream(url_stream)
    else:
        log('[Daddylive] Error in getting source: Invalid or missing channel data')
        #xbmcgui.Dialog().ok('Error', 'Error getting source: Invalid or missing channel data')


def list_gen():
    chData = channels()
    for c in chData:
        addDir(c[1], build_url({'mode': 'play', 'url': baseurl + '/' + c[0]}), False)
    closeDir()


def channels():
    url = baseurl + '/24-7-channels.php'
    do_adult = addon.getSetting('adult_pw')
    hea = {'Referer': baseurl + '/', 'user-agent': UA,}
    resp = session.post(url, headers=hea).text
    ch_block = re.compile('<center><h1(.+?)tab-2', re.MULTILINE | re.DOTALL).findall(str(resp))
    chan_data = re.compile('href=\"(.*)\" target(.*)<strong>(.*)</strong>').findall(ch_block[0])
    channels = []
    for c in chan_data:
        if not '18+' in c[2]:
            channels.append([c[0], c[2]])
        if do_adult == 'lol' and '18+' in c[2]:
            channels.append([c[0], c[2]])
    return channels



def get_ltv_link(resp):
    regex_pattern = re.compile(r'''(?:source|src|file)['"]*:\s*(?:"|')(.*?)(?:"|')''', flags=re.DOTALL+re.I)
    regex_pattern1 = re.compile(r'''(?s)script>\s*var.*?"([^"]*)''', flags=re.DOTALL+re.I)
    links = re.findall('(https?:\/\/[^\s]+\.m3u8)', resp)
    if not links: links = regex_pattern.findall(resp)
    # logger(f'play provider links: {links}\nresp: {resp}')
    links = [x for x in links if '.m3u8' in x]
    if not links:
        links = regex_pattern1.findall(resp)
        # logger(f'play provider links3: {links}')
        if links: links = [base64.b64decode(links[0]).decode('utf-8')]
    # logger(f'play provider links4: {links}')
    links = [x for x in links if '.m3u8' in x]
    if not links:
        link = base64.b64decode(unhunt(resp))
        iurl = link.decode('utf-8', errors='ignore')
        iurl = str(iurl).split('https')
        # logger(f'play provider iurl: {iurl}') # ['ޝ\x1dyԨ\x1e', '://webhdrunns.mizhls.ru/lb/premium347/index.m3u8']
        links = [f'https{iurl[1]}']
        # logger(f'play provider links: {repr(links)}') # 'https://webhdrunns.mizhls.ru/lb/premium347/index.m3u8'
    if not links: return
    links = [x for x in links if '.m3u8' in x]
    links = list(set(links))
    if len(links) > 0: return links
    else: return


def PlayStream(url):
    link = links = None
    hea = {'Referer': baseurl + '/', 'user-agent': UA, }
    log(f'url: {url}\nhea: {hea}')
    resp = session.post(url, headers=hea).text
    # log(f'resp: {resp}')
    url_1 = re.findall('iframe src="([^"]*)', resp)[0]
    hea = {'Referer': url, 'user-agent': UA, }
    log(f'url_1: {url_1}\nhea: {hea}')
    resp2 = session.post(url_1, headers=hea, timeout=10).text
    # log(f'resp: {resp}')

    links = get_ltv_link(resp2)
    if len(links) > 1:
        dialog = xbmcgui.Dialog()
        ret = dialog.select('Choose Stream', links)
        log(f'ret: {ret}')
        link = links[ret]
    else: link = links[0]
    log(f'link: {link}')
    if link:
        parsed_url = urlparse(url_1)
        referer = f'{parsed_url.scheme}://{(parsed_url.netloc or parsed_url.path)}'
        referer = quote_plus(referer)
        user_agent = quote_plus(UA)
        final_link = f'{link}|Referer={referer}/&Origin={referer}&Keep-Alive=true&User-Agent={user_agent}'
        #final_link = f'{decoded_link}|Referer={referer}/&Origin={referer}&Keep-Alive=true&User-Agent={user_agent}'
        final_link = f'{link}|Referer={referer}/&Origin={referer}&Keep-Alive=true&User-Agent={user_agent}'
        log(f'final_link: {final_link}')
        liz = xbmcgui.ListItem('Daddylive', path=final_link)
        if addon.getSetting('stream_plugin') == 'true':
            liz.setProperty('inputstream', 'inputstream.ffmpegdirect')
            liz.setMimeType('application/x-mpegURL')
            liz.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            liz.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
            liz.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        xbmcplugin.setResolvedUrl(addon_handle, True, liz)
    else: log(f'no link found in resp2: {resp2}')


mode = params.get('mode', None)

if not mode:
    Main_Menu()
else:
    log(f'params: {params}')
    if mode == 'menu':
        servType = params.get('serv_type')
        if servType == 'sched':
            Menu_Trans()
        if servType == 'live_tv':
            list_gen()

    if mode == 'showChannels':
        transType = params.get('trType')
        channels = getTransData(transType)
        ShowChannels(transType, channels)

    if mode == 'trList':
        transType = params.get('trType')
        channels = json.loads(params.get('channels'))
        TransList(transType, channels)

    if mode == 'trLinks':
        trData = params.get('trData')
        getSource(trData)

    if mode == 'play':
        link = params.get('url')
        PlayStream(link)