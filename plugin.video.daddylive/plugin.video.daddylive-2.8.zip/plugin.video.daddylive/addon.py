# -*- coding: utf-8 -*-
import os
import sys
import urllib
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import urllib3
import re
import json
import html
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl
from datetime import datetime, timedelta

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.daddylive')

mode = addon.getSetting('mode')
baseurl = 'https://dlhd.sx/'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0'
json_url = '{}stream/stream-{}.php'.format(baseurl, '%s')
FANART = addon.getAddonInfo('fanart')
ICON = addon.getAddonInfo('icon')


def build_url(query):
    return base_url + '?' + urlencode(query)


def Main_Menu():
    menu = [
        ['LIVE SPORTS', 'sched'],
        ['LIVE TV', 'live_tv'],
    ]
    for m in menu:
        li = xbmcgui.ListItem(m[0])
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '', 'sorttitle': '', 'plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': ICON, 'fanart': FANART})
        url_li = build_url({'mode': 'menu', 'serv_type': m[1]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_li, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)


def Menu_Trans():
    categs = getCategTrans()
    for categ_name, events_list in categs:
        li = xbmcgui.ListItem(str(categ_name))
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '', 'sorttitle': '', 'plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': ICON, 'fanart': FANART})
        url_li = build_url({'mode': 'trList', 'trType': categ_name})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_li, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)


def getCategTrans():
    hea = {'User-Agent': UA}
    schedule = requests.get('https://dlhd.sx/schedule/schedule-generated.json', headers=hea, timeout=10).json()
    categs = []
    for date_key, events in schedule.items():
        for categ, events_list in events.items():
            categs.append((categ, json.dumps(events_list)))
    return categs


def getTransData(categ):
    hea = {'User-Agent': UA}
    trns = []
    categs = getCategTrans()
    for categ_name, events_list_json in categs:
        if categ_name == categ:
            events_list = json.loads(events_list_json)
            for item in events_list:
                event = item.get('event')
                time = item.get('time')
                title = f'({time}) {event}'
                channels = item.get('channels')
                trns.append([title, [(channel.get('channel_id'), channel.get('channel_name')) for channel in channels]])
    return trns


def TransList(categ):
    trns = getTransData(categ)
    for t in trns:
        title = html.unescape(t[0])
        li = xbmcgui.ListItem(title)
        li.setInfo(type='video', infoLabels={'title': '', 'sorttitle': '', 'plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': ICON, 'fanart': FANART})
        li.setProperty("IsPlayable", 'true')
        url_li = build_url({'mode': 'trLinks', 'trData': str(t)})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_li, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)


def getSource(trData):
    data = eval(unquote(trData))
    if data and len(data[1]) > 0:
        url_stream = 'https://dlhd.sx/stream/stream-{}.php'.format(data[1][0][0])
        print("url_stream:", url_stream)
        xbmcplugin.setContent(addon_handle, 'videos')
        PlayStream(url_stream)
    else:
        print("Error: Invalid data format")
    return


def list_gen():
    base_url = baseurl
    chData = channels()
    for c in chData:
        li = xbmcgui.ListItem(c[1])
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': c[1], 'sorttitle': '', 'plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': ICON, 'fanart': FANART})
        url_stream = build_url({'mode': 'play', 'url': base_url + c[0]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_stream, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)


def channels():
    url = baseurl + '/24-7-channels.php'
    do_adult = xbmcaddon.Addon().getSetting('adult_pw')

    hea = {
        'Referer': baseurl + '/',
        'user-agent': UA,
    }

    resp = requests.post(url, headers=hea).text
    ch_block = re.compile('<center><h1(.+?)tab-2', re.MULTILINE | re.DOTALL).findall(str(resp))
    chan_data = re.compile('href=\"(.*)\" target(.*)<strong>(.*)</strong>').findall(ch_block[0])

    channels = []
    for c in chan_data:
        if not "18+" in c[2]:
            channels.append([c[0], c[2]])
        if do_adult == 'lol' and "18+" in c[2]:
            channels.append([c[0], c[2]])

    return channels


def PlayStream(link):
    url = link

    hea = {
        'Referer': baseurl + '/',
        'user-agent': UA,
    }

    resp = requests.post(url, headers=hea).text
    url_1 = re.compile('iframe src="(.*)" width').findall(resp)[0]

    hea = {
        'Referer': url,
        'user-agent': UA,
    }

    resp = requests.post(url_1, headers=hea).text
    stream = re.compile('source:\'(.*)\'').findall(resp)[-1]
    stream_url = stream
    hdr = 'Referer=' + quote(str(url_1)) + '&User-Agent=' + UA
    play_item = xbmcgui.ListItem(path=stream + '|' + hdr)

    import inputstreamhelper
    PROTOCOL = 'hls'
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=stream)
        play_item.setMimeType('application/x-mpegurl')
        play_item.setContentLookup(False)
        if sys.version_info >= (3, 0, 0):
            play_item.setProperty('inputstream', is_helper.inputstream_addon)
        else:
            play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)

        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)


def get_local_time(utc_time_str):
    event_time_utc = datetime.strptime(utc_time_str, '%Y-%m-%dT%H:%M:%S%z')
    event_time_local = event_time_utc + timedelta(minutes=xbmc.getInfoLabel('System.CurrentTimeZoneOffset'))

    return event_time_local.strftime('%Y-%m-%d %H:%M:%S')


mode = params.get('mode', None)

if not mode:
    Main_Menu()
else:
    if mode == 'menu':
        servType = params.get('serv_type')
        if servType == 'sched':
            Menu_Trans()
        if servType == 'live_tv':
            list_gen()

    if mode == 'trList':
        transType = params.get('trType')
        TransList(transType)

    if mode == 'trLinks':
        trData = params.get('trData')
        getSource(trData)

    if mode == 'play':
        link = params.get('url')
        PlayStream(link)