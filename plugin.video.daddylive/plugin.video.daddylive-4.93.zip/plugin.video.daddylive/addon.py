# -*- coding: utf-8 -*-

import re
import sys
import json
import html
import time

from traceback import print_exc
from urllib.parse import urlencode, quote, unquote, parse_qsl, quote_plus, urlparse
from datetime import datetime, timedelta, timezone
import requests
import xbmc
import xbmcvfs
import xbmcgui
import xbmcplugin
import xbmcaddon
from base64 import b64decode

addon_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.daddylive')

mode = addon.getSetting('mode')
baseurl = addon.getSetting('baseurl')
# json_url = f'{baseurl}/stream/stream-%s.php'
schedule_path = addon.getSetting('schedule_path').strip()
schedule_url = f'{baseurl}/{schedule_path}'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36'#UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
FANART = addon.getAddonInfo('fanart')
ICON = addon.getAddonInfo('icon')
debug = addon.getSetting('debug') == "true"
regex_pattern = re.compile(r'''iframe src="(.*?)"''', flags=re.DOTALL+re.I)
# Cache for schedule and live tv
schedule_cache = None
cache_timestamp = 0
livetv_cache = None
livetv_cache_timestamp = 0
cache_duration = 900  # 15 minutes = 900 seconds

AUTH_SERVER = "https://top2new.newkso.ru"
CDN1_BASE = "https://top1.newkso.ru/top1/cdn"
CDN_DEFAULT = "newkso.ru"

hea = {
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en',
        'Accept-Encoding': 'gzip, deflate, br',
        'Referer': baseurl,  # Uses the same baseurl as Referer
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'DNT': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-GPC': '1'
    }

def make_session(url=baseurl):
    session = requests.Session()
    retries = requests.adapters.Retry(total=3, backoff_factor=0.3, status_forcelist=(429, 500, 502, 503, 504, 520, 521, 522, 524, 530))
    session.mount(url, requests.adapters.HTTPAdapter(max_retries=retries, pool_maxsize=100))
    return session


# session = make_session()


def log(msg):
    if debug: xbmc.log(f'dlhd debug: {msg}', xbmc.LOGINFO)


def preload_cache():
    global schedule_cache, cache_timestamp
    global livetv_cache, livetv_cache_timestamp

    now = time.time()

    # Preload LIVE SPORTS schedule
    try:
        hea = {
            'User-Agent': UA,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en',
            'Accept-Encoding': 'gzip, deflate, br',
            'Referer': baseurl,
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'DNT': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-GPC': '1'
        }
        response = requests.get(schedule_url, headers=hea, timeout=10)
        if response.status_code == 200:
            schedule_cache = response.json()
            cache_timestamp = now
    except Exception as e:
        log(f"Failed to preload LIVE SPORTS schedule: {e}")

    # Preload LIVE TV channels
    try:
        livetv_cache = channels(fetch_live=True)
        livetv_cache_timestamp = now
    except Exception as e:
        log(f"Failed to preload LIVE TV channels: {e}")


def clean_category_name(name):
    """Cleans up HTML entities from sport categories."""
    if isinstance(name, str):
        # Decode HTML entities only
        name = html.unescape(name).strip()
    return name

def get_timezone_offset_minutes():
    millis = 1288483950000
    ts = millis * 1e-3
    utc_offset = datetime.fromtimestamp(ts) - datetime.utcfromtimestamp(ts)
    timezone_offset_minutes = utc_offset / timedelta(minutes=1)
    # log(f'utc_offset: {utc_offset} timezone_offset_minutes: {timezone_offset_minutes}')
    return timezone_offset_minutes

def get_local_time(utc_time_str):
    time_format = addon.getSetting('time_format')

    if not time_format: time_format = '12h'
    timezone_offset_minutes = get_timezone_offset_minutes()
    log(f'utc_time_str: {utc_time_str} timezone_offset_minutes: {timezone_offset_minutes}')
    try: event_time_utc = datetime.strptime(utc_time_str, '%H:%M')
    except TypeError: event_time_utc = datetime(*(time.strptime(utc_time_str, '%H:%M')[0:6]))
    #timezone_offset_minutes = -300
    user_timezone = addon.getSetting('epg_timezone')

    if not user_timezone: user_timezone = 0
    else: user_timezone = int(user_timezone)

    dst_enabled = addon.getSettingBool('dst_enabled')
    if dst_enabled: user_timezone += 1

    timezone_offset_minutes = user_timezone * 60
    event_time_local = event_time_utc + timedelta(minutes=timezone_offset_minutes)

    if time_format == '12h': local_time_str = event_time_local.strftime('%I:%M %p').lstrip('0')
    else: local_time_str = event_time_local.strftime('%H:%M')

    return local_time_str


def build_url(query):
    return addon_url + '?' + urlencode(query)


def addDir(title, dir_url, is_folder=True):
    title = str(title)
    item = xbmcgui.ListItem(title, offscreen=True)
    infotag = item.getVideoInfoTag()
    infotag.setMediaType('video')
    infotag.setTitle(title)
    infotag.setPlot('Daddylive')
    item.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': ICON, 'fanart': FANART})
    if is_folder is True: item.setProperty("IsPlayable", 'false')
    else: item.setProperty("IsPlayable", 'true')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=dir_url, listitem=item, isFolder=is_folder)


def closeDir():
    xbmcplugin.endOfDirectory(addon_handle)


def Main_Menu():
    menu = [['LIVE SPORTS', 'sched'], ['LIVE TV', 'live_tv'],]
    for m in menu:
        addDir(m[0], build_url({'mode': 'menu', 'serv_type': m[1]}))
    closeDir()


def getCategTrans():
    global schedule_cache, cache_timestamp, hea

    categs = []
    try:
        schedule = requests.get(schedule_url, headers=hea, timeout=10, verify=False).json()
        for date_key, events in schedule.items():
            for categ, events_list in events.items():
                categ = clean_category_name(categ)
                categs.append((categ, json.dumps(events_list)))
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error fetching category data: {e}")
        return []

    return categs


def Menu_Trans():
    categs = getCategTrans()
    if not categs: return
    for categ_name, events_list in categs:
        addDir(categ_name, build_url({'mode': 'showChannels', 'trType': categ_name}))
    closeDir()


def ShowChannels(categ, channels_list):
    for item in channels_list:
        addDir(item.get('title'), build_url({'mode': 'trList', 'trType': categ, 'channels': json.dumps(item.get('channels'))}), True)
    closeDir()


def getTransData(categ):
    trns = []
    categs = getCategTrans()
    for categ_name, events_list_json in categs:
        if categ_name == categ:
            events_list = json.loads(events_list_json)
            for item in events_list:
                event = item.get('event')
                time_str = item.get('time')
                event_time_local = get_local_time(time_str)
                title = f'{event_time_local} {event}'
                channels = item.get('channels')
                
                # Fix: Accept both list and dict structures
                if isinstance(channels, dict):
                    # Convert dict to list of dicts
                    channels = list(channels.values())

                if isinstance(channels, list) and all(isinstance(channel, dict) for channel in channels):
                    trns.append({'title': title, 'channels': [{'channel_name': channel.get('channel_name'), 'channel_id': channel.get('channel_id')} for channel in channels]})
                else: log(f"Unexpected data structure in 'channels' after conversion: {channels}")
    return trns


def TransList(categ, channels):
    for channel in channels:
        channel_title = html.unescape(channel.get('channel_name'))
        channel_id = channel.get('channel_id')
        addDir(channel_title, build_url({'mode': 'trLinks', 'trData': json.dumps({'channels': [{'channel_name': channel_title, 'channel_id': channel_id}]})}), False)
    closeDir()


def getSource(trData):
    data = json.loads(unquote(trData))
    channels_data = data.get('channels')
    if channels_data is not None and isinstance(channels_data, list):
        url_stream = f'{baseurl}/stream/stream-{channels_data[0]["channel_id"]}.php'
        xbmcplugin.setContent(addon_handle, 'videos')
        PlayStream(url_stream)
    else:
        log('[Daddylive] Error in getting source: Invalid or missing channel data')
        #xbmcgui.Dialog().ok('Error', 'Error getting source: Invalid or missing channel data')


def list_gen():
    chData = channels()
    for c in chData:
        addDir(c[1], build_url({'mode': 'play', 'url': baseurl + '/' + c[0]}), False)
    closeDir()


def channels():
    url = baseurl + '/24-7-channels.php'
    do_adult = addon.getSetting('adult_pw')
    hea = {'Referer': baseurl + '/', 'user-agent': UA,}
    resp = requests.get(url, headers=hea).text
    ch_block = re.compile('<center><h1(.+?)tab-2', re.MULTILINE | re.DOTALL).findall(str(resp))
    chan_data = re.compile('href=\"(.*)\" target(.*)<strong>(.*)</strong>').findall(ch_block[0])
    channels = []
    for c in chan_data:
        if not '18+' in c[2]:
            channels.append([c[0], c[2]])
        if do_adult == 'lol' and '18+' in c[2]:
            channels.append([c[0], c[2]])
    return channels


def get_link(resp):
    patterns = [
        r'''(https?:\/\/\S+\.m3u8)''',
        r'''(?:file)["']?\s*[:=]?\s*["']([^"']+)''',
        r'''(?s)script>\s*var.*?"([^"]*)''',
        r'''"(aHR0.+?)"''',
        r'''encryptedSource\s*=\s*"(.+?)"''',
        r"source:\s*'(.+?)'"
    ]

    links = []
    for pattern in patterns:
        match = re.search(pattern, resp)
        if match:
            link = match.group(1)
            # log(f'get_link pattern: {pattern}\nlink: {link}')
            if link and '.m3u8' not in link:
                try:
                    elink = b64decode(link).decode('utf-8', errors='ignore')  # Decode base64-encoded link (if applicable)
                    if elink.startswith('://'): link = f'https{elink[1]}'
                except Exception as err: log(f'get_link link: {link} err: {err}')
            links.append(link)
    if not links: log(f'get_link resp: {resp}')
    return links


def get_ltv_link(resp):
    regex_pattern = re.compile(r'''(?:source|src|file)['"]*:\s*(?:"|')(.*?)(?:"|')''', flags=re.DOTALL+re.I)
    regex_pattern1 = re.compile(r'''(?s)script>\s*var.*?"([^"]*)''', flags=re.DOTALL+re.I)
    links = re.findall(r'(https?:\/\/[^\s]+\.m3u8)', resp)
    if not links: links = regex_pattern.findall(resp)
    # log(f'play provider links: {links}\nresp: {resp}')
    links = [x for x in links if '.m3u8' in x]
    if not links:
        links = regex_pattern1.findall(resp)
        # log(f'play provider links3: {links}')
        if links: links = [b64decode(links[0]).decode('utf-8')]
    # log(f'play provider links4: {links}')
    links = [x for x in links if '.m3u8' in x]
    if not links:
        link = b64decode(resp)
        iurl = link.decode('utf-8', errors='ignore')
        iurl = str(iurl).split('https')
        # log(f'play provider iurl: {iurl}') # ['ޝ\x1dyԨ\x1e', '://webhdrunns.mizhls.ru/lb/premium347/index.m3u8']
        links = [f'https{iurl[1]}']
        # log(f'play provider links: {repr(links)}') # 'https://webhdrunns.mizhls.ru/lb/premium347/index.m3u8'
    if not links: return
    links = [x for x in links if '.m3u8' in x]
    links = list(set(links))
    if len(links) > 0: return links
    else: return


def relv_daddy(link):
    strmid = link.split('stream-')[1].replace('.php', '') or link.split('id=ch')[1] or link.split('id=')[1]# re.findall(r'.*?(\d+)\.php', link)[0]
    # UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
    if not link.startswith('http'): url = f'{baseurl}/{link}'
    else: url = link
    urlb = None
    hea = {'Referer': f'{baseurl}/', 'User-Agent': UA}
    resp = requests.get(url, headers=hea).text
    # log(f'play provider url: {url}\nresp1: {resp}')
    if not resp: return
    m_iframe = re.search(r'''iframe\s+src="([^"]+)"''', str(resp), re.DOTALL)
    if not m_iframe: return log('Playback Error Could not find iframe URL.')

    urla = m_iframe.group(1)
    hea = {'Referer': url, 'User-Agent': UA, }
    resp = requests.get(urla, headers=hea, timeout=10).text # request(urla, headers=hea, timeout=10)
    ref = '{uri.scheme}://{uri.netloc}'.format(uri=urlparse(urla))
    channelKey = re.findall(r'''var channelKey\s*=\s*["'](.+?)['"]''', str(resp), re.DOTALL)
    server_info = re.findall(r'''var m3u8Url\s*=(.+?);''', str(resp), re.DOTALL)
    url_b = re.findall(r'''source\s*:\s*["']?(.+?)['"]?\,''', str(resp), re.DOTALL)
    log(f'1channelKey: {repr(channelKey)} server_info: {repr(server_info)}\nurl_b: {repr(url_b)}')
    if re.search(r'm3u8Url|m3u8', str(url_b)):
        # if url_b == "m3u8Url" or url_b == "m3u8":
        try:
            auth_host = re.findall(r'''(https?:\/\/[^\s]+/auth\.php\?channel_id=)''', str(resp), re.DOTALL)
            log(f'auth_host: {auth_host}')
            if auth_host: auth_host = auth_host[0]
            else: auth_host = 'https://top2new.newkso.ru/auth.php?channel_id='
            authTs = re.findall(r'''var authTs\s*=\s*["'](.+?)['"]''', str(resp), re.DOTALL)[0]
            authRnd = re.findall(r'''var authRnd\s*=\s*["'](.+?)['"]''', str(resp), re.DOTALL)[0]
            authSig = re.findall(r'''var authSig\s*=\s*["'](.+?)['"]''', str(resp), re.DOTALL)[0]
            auth_url = auth_host + channelKey[0] + '&ts=' + authTs + '&rnd=' + authRnd + '&sig=' + quote(authSig)
            auth_hdr = {'Referer': ref+"/", 'Origin': ref, 'User-Agent': UA, 'Connection':'keep-alive',}
            auth_resp = requests.get(auth_url, headers=auth_hdr, verify=False, timeout=10).content.decode('utf-8')
            log(f'auth_resp: {auth_resp}')
        except: pass
        if not server_info and "wikisport" in resp:  # 04-02-25
            try:
                iframe_src = re.findall(r'iframe src="(.+?)"', resp)[0]
                r = requests.get(iframe_src).text
                iframe_src = re.findall(r'iframe src="(.+?)"', resp)[0]
                resp = requests.get(iframe_src).text
            except: pass
            channelKey = re.findall(r'var channelKey.+?\"(.+?)\"', resp, re.DOTALL)
            # server_info = re.findall(r'var m3u8Url\s*=(.+?);', r, re.DOTALL)
            ref = '{uri.scheme}://{uri.netloc}'.format(uri=urlparse(iframe_src))
            log(f'2channelKey: {repr(channelKey)} server_info: {repr(server_info)}')
        if channelKey: channelid = channelKey[0]
        else: log(f'play provider urla: {urla}\nresp2: {resp}'); return
        if channelid.startswith('bet'):
            if strmid.isdigit(): channelid = f'mono{strmid}'
            else: channelid = strmid

        server_lookup = f'{ref}/server_lookup.php?channel_id={channelid}'
        hea2 = {'Referer': urla, 'user-agent': UA, }
        # log(f'server_lookup: {server_lookup}')
        server_resp = requests.get(server_lookup, headers=hea2, verify=False).content.decode('utf-8')
        try:
            serverKey = server_resp.get("server_key")
            url_b = url_b[0]
            if url_b == "m3u8Url":
                server = re.findall(r'''serverKey\s*\+\s*["'](.+?)['"]\s*\+\s*serverKey''', str(resp), re.DOTALL)[0]
                fname = re.findall(r'''channelKey\s*\+\s*["'](.+?)['"]''', str(resp), re.DOTALL)[-1]
                urlb = f'https://{serverKey}{server}{serverKey}/{channelKey}{fname}'
            elif url_b == "m3u8":
                server = re.findall(r'''sk\s*\+\s*["'](.+?)['"]\s*\+\s*sk''', str(resp), re.DOTALL)[0]
                fname = re.findall(r'''channelKey\s*\+\s*["'](.+?)['"]''', str(resp), re.DOTALL)[-1]
                url_b = f'https://top1.newkso.ru/top1/cdn/{channelid}/mono.m3u8' if serverKey == 'top1/cdn' else f'https://{serverKey}{server}{serverKey}/{channelid}{fname}'
                # js_variables = ''
                # try:
                    # js_variables += '{}'.format(re.findall(r'''(var authTs\s*=\s*["'].+?['"];)''', str(resp), re.DOTALL)[0])
                    # js_variables += '{}'.format(re.findall(r'''(var authRnd\s*=\s*["'].+?['"];)''', str(resp), re.DOTALL)[0])
                    # js_variables += '{}'.format(re.findall(r'''(var authSig\s*=\s*["'].+?['"];)''', str(resp), re.DOTALL)[0])
                # except:
                    # pass
                # js_variables += 'var sk = "{}";'.format(serverKey)
                # js_variables += '{}'.format(re.findall(r'''(var channelKey\s*=\s*["'].+?['"];)''', str(resp), re.DOTALL)[0])
                # js_variables += '{}'.format(re.findall(r'''(var m3u8\s.+?;)''', str(resp), re.DOTALL)[0])
                # import js2py
                # js = js2py.EvalJs()
                # js.execute(js_variables)
                # urlb = js.m3u8
        except: log(f'server_lookup: {server_lookup}\nresp: {resp}')
    elif 'src' in url_b:
        urlb = re.findall(r'''src=\s*["'](.+?)['"]''', resp, re.DOTALL)[0]
    elif 'playbackURL' in url_b:
        char_codes = json.loads(re.findall(r'''=\s*(\[\s*\[.+?\]\s*\])''', resp, re.DOTALL)[-1])
        char_codes.sort(key=lambda a: a[0])
        f1, f2 = re.findall(r'''return\s*(\d+);''', resp, re.DOTALL)
        k = int(f1) + int(f2)
        playbackURL = ''
        for e in char_codes:
            v = e[1]
            playbackURL += chr(int(re.sub(r'\D', '', b64decode(v).decode('utf-8'))) - k)
        urlb = playbackURL


    # urlb = get_link(resp)
    if not urlb: logger(f' error resp: {resp}'); return 
    parsed_url = urlparse(urla)
    referer = f'{parsed_url.scheme}://{(parsed_url.netloc or parsed_url.path)}'
    referer = quote_plus(referer)
    return f'{urlb}|Referer={referer}/&Origin={referer}&Keep-Alive=true&User-Agent={quote_plus(UA)}'



def PlayStream(url):
    link = relv_daddy(url)
    if link:
        log(f'final_link: {link}')
        liz = xbmcgui.ListItem('Daddylive', path=link)
        if addon.getSetting('stream_plugin') == 'true':
            liz.setProperty('inputstream', 'inputstream.ffmpegdirect')
            liz.setMimeType('application/x-mpegURL')
            liz.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            liz.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
            liz.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        xbmcplugin.setResolvedUrl(addon_handle, True, liz)
    else: log('no link found in resp:')


mode = params.get('mode', None)

if not mode:
    Main_Menu()
else:
    log(f'params: {params}')
    if mode == 'menu':
        servType = params.get('serv_type')
        if servType == 'sched':
            Menu_Trans()
        if servType == 'live_tv':
            list_gen()

    if mode == 'showChannels':
        transType = params.get('trType')
        channels = getTransData(transType)
        ShowChannels(transType, channels)

    if mode == 'trList':
        transType = params.get('trType')
        channels = json.loads(params.get('channels'))
        TransList(transType, channels)

    if mode == 'trLinks':
        trData = params.get('trData')
        getSource(trData)

    if mode == 'play':
        link = params.get('url')
        PlayStream(link)