### ############################################################################################################
### ############################################################################################################
### Imports ###
import xbmc,xbmcgui,xbmcaddon,xbmcplugin,urllib,re,os,sys,time,math,datetime, requests
from xml.etree.ElementTree import ElementTree
import http.cookiejar as cookielib
print(sys.argv)
#from resources.libs import main
from common import *
from common import (_addon,addon,_plugin,_artIcon,_artFanart,PlayItCustom,_addonPath,_SaveFile,_OpenFile,_datapath)
selfAddon=_plugin

### ############################################################################################################
### ############################################################################################################
SiteName='[COLOR lime]Live TV[COLOR white]- Live Sport[/COLOR][/COLOR] '
SiteTag='streamlive.to'
mainSite='https://www.streamlive.to/'
iconSite='https://www.streamlive.to/images/fanart.png' 
fanartSite='https://www.streamlive.to/images/fanart.png' #_artFanart
colors={'0':'white','1':'red','2':'blue','3':'green','4':'yellow','5':'','6':'lime','7':'','8':'cornflowerblue','9':'blueviolet'}

CR='[CR]'
MyAlphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
MyBrowser=['User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3']
### ############################################################################################################
site=addpr('site','')
section=addpr('section','')
url=addpr('url','')
sections={'series':'series','movies':'movies'}
thumbnail=addpr('img','')
fanart=addpr('fanart','')
page=addpr('page','')
### ############################################################################################################
### ############################################################################################################
ApiLiveDomain=addst('DefaultApiLiveList','Default'); 
if ApiLiveDomain=='streamlive.to': doMain="https://www.streamlive.to/"; 
else: doMain="https://www.streamlive.to/"; 
headers={'Referer':doMain}; 



### ############################################################################################################
### ############################################################################################################
CookieJarFile=xbmc.translatePath(os.path.join(_datapath,'cookies.txt'))
#if (isFile(CookieJarFile)==True) :
  #os.remove(CookieJarFile)

UseAccount=tfalse(addst('enable-accountinfo','false')); 
AccountUsername=addst('username',''); 
AccountPassword=addst('password',''); 
LastUsername=addst('last_username',''); 
LastPassword=addst('last_password','');
if len(AccountUsername)==0: UseAccount=False
elif len(AccountPassword)==0: UseAccount=False

### ############################################################################################################
### ############################################################################################################
def About(head=''+cFL(SiteName,'blueviolet')+'',m=''):
	m=''
	if len(m)==0:
		
		m+=CR+'Site Name:  '+SiteName+CR+'Site Tag:  '+SiteTag+CR+'Site Domain:  '+mainSite+CR+'Site Icon:  '+iconSite+CR+'Site Fanart:  '+fanartSite
		m+=CR+'Age:  Please make sure you are of a valid age to watch the material shown.'
		m+=CR+CR+'Known Hosts for Videos:  '
		m+=CR+'RTMP Live Streams'
		m+=CR+CR+'Features:  '
		m+=CR+'* Includes my Increased List of Categories.  '
		m+='Those which often have no items are marked as such.  '
		m+='Some of My English Shortcuts are included as well.'
		m+=CR+'* Browse Live Channels.'
		m+=CR+'* Play Live Channels.'
		m+=CR+CR+'Notes:  '
		m+=CR+'* Watch Wolrd Live TV and Live Sport.'

	String2TextBox(message=cFL(m,'cornflowerblue'),HeaderMessage=head)
	#RefreshList()

### ############################################################################################################
### ############################################################################################################
def DoE(e): xbmc.executebuiltin(E)
def DoA(a): xbmc.executebuiltin("Action(%s)" % a)
 

try: from sqlite3 import dbapi2 as orm
except: from pysqlite2 import dbapi2 as orm
DB='sqlite'; DB_DIR=os.path.join(xbmc.translatePath("special://database"),'Textures13.db'); 
if os.path.isfile(DB_DIR)==True: print("Texture Database Found: "+DB_DIR); 
else: print("Unable to locate Texture Database")

def unCacheAnImage(url):
	if os.path.isfile(DB_DIR)==True:               
		db=orm.connect(DB_DIR)
		s='DELETE FROM texture WHERE url = "'+url+'";' #print s; 
		db.execute(s) 
		db.commit(); db.close(); 

### ############################################################################################################
### ############################################################################################################

def getToken(url):

	html=requests.get(url).content
	token_url=re.compile('\$.getJSON\("(.+?)",').findall(html)[0]
	time_now=datetime.datetime.now()
	epoch=time.mktime(time_now.timetuple())+(time_now.microsecond/1000000.)
	epoch_str=str('%f' % epoch); epoch_str=epoch_str.replace('.',''); epoch_str=epoch_str[:-3]
	token_url=token_url + '&_=' + epoch_str
	#
	tokhtml=requests.get(token_url+'&_='+str(epoch), headers={'Referer':url}).content
	debob('tokhtml: ')
	debob(tokhtml)
	token=re.compile('":"(.+?)"').findall(tokhtml)[0]
	token=re.compile('":"(.+?)"').findall(requests.get(token_url+'&_='+str(epoch), headers={'Referer':url}).content)[0]
	debob(token)
	return token
def doCtoD(c):
	if len(c) > 0:
		d=""; ic=len(c); i=0; 
		while (i<ic):
			try:
				if i%3==0: d+="%";
				else: d+=c[i]
			except: pass; debob({'d[error]':d})
			i=i+1
		debob({'d':d})
		d=urllib.unquote_plus(d)
		debob({'du':d})
		return d
	else: return ''
def doXTtoXZ(x,tS,b=1024,p=0,s=0,w=0,r2=''):
		l=len(x); t=tS.split(','); r=[]
		
		for j in range(int(math.ceil(l/b)),0, -1):
			for i in range(min(l,b),0, -1):
				w |= int(t[ord(x[p])-48]) << s
				p += 1
				if (s):
					r.append(chr(165 ^ w & 255))
					w >>= 8
					s -= 2
				else:
					s = 6
			l -=1
		r = ''.join(r)
		return r
		
def is_expired (cookieFilename):
	if (isFile(CookieJarFile)==False) :
			print("Expired")
			return True
	cj = cookielib.LWPCookieJar()
	cj.revert(cookieFilename, True, True)
	now = time.time()
	for Cookie in cj:
		if Cookie.is_expired(now) :
			print("Expired")
			return True
	return False
def iLivePlay(mname='',murl='',thumb='',LinkNo=''):
    if '.to/view/' in murl: murl=murl.replace('.to/view/','.to/view-kodi-new/')
    if '.to/view-kodi/' in murl: murl=murl.replace('.to/view-kodi/','.to/view-kodi-new/')
    if 'http:/' in murl: murl=murl.replace('http:/','https:/')
    print("murl " + murl)
            
        
	
    menuurl=""+murl; name=mname; 
    debob({'menuurl':menuurl,'LinkNo':LinkNo,'mname':mname});

    if (str(LinkNo)=='99') and (UseAccount==True):
        DayLoggedIn = addst('dayloggedin','')
        DayLoggedInNew = str(datetime.date.today().day)
        if (isFile(CookieJarFile)==False) or (is_expired (CookieJarFile)) or (LastUsername!=AccountUsername) or (LastPassword!=AccountPassword):
                loginurl='https://www.streamlive.to/loginJson.php'
                GetLogin = nURL(loginurl,method='post',headers={'Referer':menuurl},form_data={'username':AccountUsername,'password':AccountPassword,'submit':'Login'},cookie_file=CookieJarFile,save_cookie=True)
                addstv('dayloggedin',DayLoggedInNew)
                addstv('last_username',AccountUsername)
                addstv('last_password',AccountPassword)
                print("usr " + AccountUsername)
                print("pass " + AccountPassword)
        link=nURL(menuurl,cookie_file=CookieJarFile,load_cookie=True)
    else:
        link=nURL(menuurl) #OPEN_URL(menuurl)
	
    deb('Length of html',str(len(link))); 
    #_SaveFile(os.path.join(_addonPath,'link1.html'),link); deb('saved','link1.html')
    try: _SaveFile(os.path.join(_addonPath,'link1.html'),link); deb('saved','link1.html')
    except: pass

    vID=re.compile('(?:view-kodi|view-channel|view-kodi)?/(\d+)').findall(menuurl)[0]
    #vID=re.compile('\D+-channel/(\d+)').findall(menuurl)[0]
    menuurl2='http://www.mobileonline.tv/channel.php?n=%s'%vID
    TimeOut=str(addst('DefaultTimeOut','15'))
    SleeperTime=str(addst('DefaultSleepBeforePlay','2000'))

    #LinkNo='99'
    if not str(LinkNo)=='99':
            link2=nURL(menuurl2)
            ## ### ## 
            if LinkNo=='': LinkNo=addst('DefaultVideoLink','2')
            if LinkNo=='': LinkNo=2
            if LinkNo=='0HLS':  LinkNo=0
            if LinkNo=='1RTMP': LinkNo=1
            if LinkNo=='2RTSP': LinkNo=2
            else: LinkNo=int(LinkNo)
            ## ### ## 
            debob({'LinkNo':LinkNo})
            playables=re.compile('<p style="font-size:30px;"><a href=(\D+://.+?) target="_blank">Link').findall(link2)
            debob({'playables':playables}); 
            playable=playables[int(LinkNo)] #0-2, 0:http, 1:rtmp, 2:rtsp
            ## ### ## 
            if not TimeOut=='0': playable+=' app=%s live=1 timeout=%s'%('',TimeOut)
            try: xbmc.sleep(int(SleeperTime))
            except: pass
            PlayItCustom(url=murl,stream_url=playable,img=thumb,title=name)
            return
            ## ### ## 
    ## ### ## 
    if '<script language=javascript>c="' in link:
            deb('method','encrypted') 
            c=re.compile('<script language=javascript>c="(.+?)"').findall(link)[0]; #debob({'c':c}); 
            cu=urllib.unquote_plus(c); #debob({'cu':cu}); 
            d=doCtoD(c); #debob({'d':d}); 

            t=re.compile('t=Array\(([0-9,]+)\)').findall(d)[0]; #debob({'t':t}); 
            x=re.compile('"\)\);\s*x\("(.+?)"').findall(link)[0]; #debob({'x':x}); 
            z=doXTtoXZ(x,t); 
            link=''+z; 

    else:
            deb('method','encryption not found')
    ## ### ## 
    ok=True
    grabNo=0 #-1

    if link:
                    deb(str(len(link)),os.path.join(_addonPath,'link.html')); 
                    _SaveFile(os.path.join(_addonPath,'link.html'),link); deb('saved','link.html')
                    if ('<span class="viewers">0</span>' in link) and ('<span class="totalviews">0</span>' in link): 
                            debob({'mname':mname,'murl':murl,'error':'Channel Offline'}); 
                            popOK(msg="This Channel is ",title="Channel Unavailable.",line2="offline at the moment.",line3=""); 
                            eod(); return
                    elif '<h3 class="na_msg">This channel is domain protected.<br/>Please upgrade your account to Premium to watch.<br/>Click here to <a href="http://www.streamlive.to/premium">upgrade to Premium account</a>.</h3>' in link: 
                            debob({'mname':mname,'murl':murl,'error':'Premium Channel'}); 
                            if UseAccount==True:
                                    popOK(msg="This Channel is ",title="Channel might be unavailable.",line2="a Premium Channel.",line3=""); 
                            else: 
                                    popOK(msg="This Channel is ",title="Channel Unavailable.",line2="a Premium Channel.",line3=""); 
                                    eod(); return
                    
                    
                    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                    playlist.clear()
                    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace("\/",'/')
                    print("****************" + link)
                    html=link  
                    streamer=re.compile('(?s)streamer:.*?"(.+?)"').findall(html)[0]
                    pageUrl=''+doMain
                    if "http" in streamer:
                    #if "https://" or "http://" in streamer:
                            if '.to/view/' in streamer: streamer=streamer.replace('.to/view/','.to/view-kodi-new/')
                            if '.to/view-kodi/' in streamer: streamer=streamer.replace('.to/view-kodi/','.to/view-kodi-new/')
                            print("streamer " + streamer)
                            PlayURL(streamer)
                            return
                    app=re.compile('xs=(.+?)"').findall(html)[0]
                    playpath=re.compile('''.*file[:,]\s*['"]([^'"]+).flv['"]''').findall(html)
                    debob(playpath)
                    playpath=playpath[grabNo]
                    newplaypath=str(playpath)
                    token=re.compile('<br>token: "(.+?)"').findall(html)[0]
                    swf=doMain+'player/player_ilive_2.swf'
                    playable='%s app=edge/?xs=%s playpath=%s swfUrl=%s pageUrl=%s live=%s timeout=%s token=%s'%(streamer,app,newplaypath,swf,pageUrl,'true',TimeOut,token)
                    print('RTMP IS '+ playable)
                    try: xbmc.sleep(int(SleeperTime))
                    except: pass
                    if '.to/view/' in murl: murl=murl.replace('.to/view/','.to/view-kodi-new/')
                    if '.to/view-kodi/' in murl: murl=murl.replace('.to/view-kodi/','.to/view-kodi-new/')
                    PlayItCustom(url=murl,stream_url=playable,img=thumb,title=name)

def SearchTITLE(title=''):
        if len(title)==0: title=showkeyboard(txtMessage=title,txtHeader="Search:  ")
        if (title=='') or (title=='none') or (title==None) or (title==False): return
        deb('Searching for',title); #title=title.replace('+','%2B').replace('&','%26').replace('?','%3F').replace(':','%3A').replace(',','%2C').replace('/','%2F').replace('=','%3D').replace('@','%40').replace(' ','%20'); 
        deb('Searching for',title);
        headers = {'Referer':'https://www.streamlive.to/movies','X-Requested-With': 'XMLHttpRequest'}
        data = {'search':title}
        url = 'https://www.streamlive.to/search.php'

        source = requests.post(url,headers= headers ,data = data)
        patron = re.compile('(?s)searchList.*?href.*?\'([^\'"]+).*?url\(\'([^\'"]+).*?title">(.*?)<')
        link = patron.findall(source.text)
        if link == [] :
                popOK(msg="No link found ",title=SiteName,line2="",line3="")
                return
        if ('movie.php?n=' in  source.text) or  ('tv-series' in source.text) :                
          for url,thumb,name in link :
                if 'http' not in thumb : thumb = 'http:' + thumb
                if 'movie' in url :
                        addDir('[COLOR cyan]%s[/COLOR]'%name, url, 'Movie_Play', thumb, thumb, '',isFolder=False)
                elif 'tv-series' in url :
                        addDir('[COLOR cyan]%s[/COLOR]'%name, url, 'Series_Epi', thumb, thumb, '',isFolder=True)

        else :
          DoSearchLIVE(title=title)
                
        set_view('movies',view_mode=addst('movies-view'));
        eod();                        

def DoSearchLIVE(title=''):
	if len(title)==0: title=showkeyboard(txtMessage=title,txtHeader="Search:  ")
	if (title=='') or (title=='none') or (title==None) or (title==False): return
	deb('Searching for',title); #title=title.replace('+','%2B').replace('&','%26').replace('?','%3F').replace(':','%3A').replace(',','%2C').replace('/','%2F').replace('=','%3D').replace('@','%40').replace(' ','%20'); 
	deb('Searching for',title);
	##
	iLiveBrowseLIVE(search=title,page='1'); 


def DoSearch(title=''):
	if len(title)==0: title=showkeyboard(txtMessage=title,txtHeader="Search:  ")
	if (title=='') or (title=='none') or (title==None) or (title==False): return
	deb('Searching for',title); title=title.replace('+','%2B').replace('&','%26').replace('?','%3F').replace(':','%3A').replace(',','%2C').replace('/','%2F').replace('=','%3D').replace('@','%40').replace(' ','%20'); 
	deb('Searching for',title); 
	##
	iLiveBrowse(search=title); 
	##
def addDir(name, url, mode, iconimage, fanart, description,isFolder):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(
        name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&fanart=" + urllib.quote_plus(fanart) + "&description=" + urllib.quote_plus(description)
    ok = True
    liz = xbmcgui.ListItem(
        name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    liz.setProperty("Fanart_Image", fanart)

    ok = xbmcplugin.addDirectoryItem(handle=int(
            sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)

    return ok

def play_url(url):
    if UseAccount==True:
        DayLoggedIn=addst('dayloggedin','')
        DayLoggedInNew=str(datetime.date.today().day)
        if (isFile(CookieJarFile)==False) or (is_expired (CookieJarFile)) or (LastUsername!=AccountUsername) or (LastPassword!=AccountPassword):
                loginurl='https://www.streamlive.to/loginJson.php'
                GetLogin=nURL(loginurl,method='post',headers={'Referer':doMain},form_data={'username':AccountUsername,'password':AccountPassword,'submit':'Login'},cookie_file=CookieJarFile,save_cookie=True)
                addstv('dayloggedin',DayLoggedInNew)
                addstv('last_username',AccountUsername)
                addstv('last_password',AccountPassword)
                print("usr " + AccountUsername)
                print("pass " + AccountPassword)
        cookie_file=CookieJarFile
        cj = cookielib.LWPCookieJar()
        cj.load(cookie_file, ignore_discard=True)
        link=requests.get(url,cookies = cj).text
    else:
        link=nURL(url) 
    if 'tv-series' in url :
        movie = 'http:'+re.findall('(?s)class="mvici-right".*?href="(.*?mp4.*?)"',link)[0]
        movie = movie.replace('download_','').replace('?','/playlist.m3u8?')

    ##else : movie = 'http:'+re.findall('"file": "(.*?(?:mp4|m3u8).*?)"',link)[0]
    else : movie = 'http:'+re.findall('source: "(.*?(?:mp4|m3u8).*?)"',link)[0]

    
    name ='';iconimage = iconSite
    listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    listitem.setInfo('video', {'Title': name})
    listitem.setProperty("IsPlayable","true")
    ok = xbmc.Player().play(movie, listitem)
    return ok

def BrowseMovie(np):
  if np == '' : np = 1
  tUrl = 'https://www.streamlive.to/moviesPages.php'
  source = requests.get(tUrl).text
  patron = re.compile('(?s)data-movie-page="(\d+)"')
  npage = patron.findall(source)[-1]
  patron = re.compile('(?s)class="ml-item".*?href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?Total Views.*?href.*?>(\d+)<.*?Category.*?href.*?>(.*?)<')
  data = {'movie_page':np,'category':'','country':'','movie_year':'','actors':'','itemspp':32}
  hdrs = {'Referer':'https://www.streamlive.to/movies','X-Requested-With': 'XMLHttpRequest'}
  html = requests.post(tUrl, headers = hdrs, data = data).text
  html = nolines(messupText(html.replace("&nbsp;",""),True,True));
  link = patron.findall(html)
  desc = ''
  for url,name,thumb,iTotalViews,Category in link:
    thumb = 'http:' + thumb
    #_addon.add_directory({'mode':'Movie_Play','site':'','section':''},{'title':'* '+cFL_(name,colors['6'])},is_folder=False,fanart=thumb,img=thumb); 

    addDir('[COLOR cyan]%s[/COLOR]'%name, url, 'Movie_Play', thumb, thumb, desc,isFolder=False)
  if int(np) + 1 <= int(npage) :
    url = str(int(np) + 1) 
    addDir('[COLOR cyan]Next >>>[/COLOR]',url , 'Movies10_Movies', iconSite, fanartSite, desc,isFolder=True)
  #url = '1' ;addDir('[COLOR cyan]Main Menu[/COLOR]',url , 'Movies10_Movies', iconSite, fanartSite, desc,isFolder=True)

  set_view('movies',view_mode=addst('movies-view'));
  eod();

def SectionMovies():
        headers={'Referer':doMain}; 
        #tUrl=doMain+"moviesPages.php"
        tUrl = 'https://www.streamlive.to/moviesPages.php'	
        deb("url",tUrl); 
        html=nURL(tUrl,headers=headers); deb("length of first page",str(len(html)));
        html=nolines(messupText(html.replace("&nbsp;",""),True,True));
        source = requests.get(tUrl).text
        patron = re.compile('(?s)data-movie-page="(\d+)"')
        page = patron.findall(source)[-1]
        #page = 1
        pn = 2
        #patron = re.compile('(?s)class="ml-item".*?href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?block">Description.*?>(.*?)<')
        patron = re.compile('(?s)class="ml-item".*?href="(.*?)".*?title="(.*?)".*?src="(.*?)"')

        link = patron.findall(html)
        while pn <= int(page):
            try:
                data = {'movie_page':pn,'category':'','country':'','movie_year':'','actors':'','itemspp':32}
                hdrs = {'Referer':'https://www.streamlive.to/movies','X-Requested-With': 'XMLHttpRequest'}
                url = 'https://www.streamlive.to/moviesPages.php'
                html = requests.post(url, headers = hdrs, data = data).text
                html = nolines(messupText(html.replace("&nbsp;",""),True,True));
                #source = requests.get(url)
                link += patron.findall(html)
                pn += 1
            except:
                pass
        #for url,name,thumb,desc in link:
        for url,name,thumb in link:
                thumb = 'http:' + thumb
                unCacheAnImage(thumb); 
                #pars={'mode':'iLivePlay','site':'','section':'','title':name,'url':url,'fanart':thumb,'img':thumb,'link':'99'}; 
                #PlotD=cFL("[CR]Language: "+''+"[CR]Category: "+''+"[CR]Viewers: "+''+"[CR]TotalViews: "+'',"tan"); 
                #addDir('[COLOR cyan]%s[/COLOR]'%name, url, 'Movie_Play', thumb, thumb, desc,isFolder=False)
                desc =''
                addDir('[COLOR cyan]%s[/COLOR]'%name, url, 'Movie_Play', thumb, thumb, desc,isFolder=False)
                #try: _addon.add_directory(pars,{'title':name+'  ['+cFL('',colors['6'])+']','plot':PlotD},is_folder=False,fanart=thumb,img=thumb,total_items=ItemCount)
                #except: pass
        set_view('movies',view_mode=addst('movies-view')); 
        eod();

def SectionTVShows(np):
    if np == '' : np = 1
    tUrl = 'https://www.streamlive.to/tvseriesPages.php'
    npage = 0 ;np1 = 1
    while 1:
        
            data = {'movie_page':np1,'category':'','country':'','movie_year':'','actors':'','itemspp':32}
            hdrs = {'Referer':'https://www.streamlive.to/tv-series-list','X-Requested-With': 'XMLHttpRequest'}
            html = requests.post(tUrl, headers = hdrs, data = data).text
            patron = re.compile('(?s)class="ml-item".*?href="(.*?)".*?title="(.*?)".*?src="(.*?)"')
            link = patron.findall(html)
            if link == []:
                    break
            npage += 1;np1  += 1
    data = {'movie_page':np,'category':'','country':'','movie_year':'','actors':'','itemspp':32}
    hdrs = {'Referer':'https://www.streamlive.to/tv-series-list','X-Requested-With': 'XMLHttpRequest'}
    html = requests.post(tUrl, headers = hdrs, data = data).text
    html = nolines(messupText(html.replace("&nbsp;",""),True,True));
    patron = re.compile('(?s)class="ml-item".*?href="(.*?)".*?title="(.*?)".*?src="(.*?)"')
    link = patron.findall(html)
    desc = ''
    for url,name,thumb in link:
            thumb = 'http:' + thumb
            unCacheAnImage(thumb);
            
            addDir('[COLOR cyan]%s[/COLOR]'%name, url, 'Series_Epi', thumb, thumb, desc,isFolder=True)
    if int(np) + 1 <= int(npage) :
      url = str(int(np) + 1) 
      addDir('[COLOR cyan]Next >>>[/COLOR]',url , 'Movies10_TVShows', iconSite, fanartSite, desc,isFolder=True)
    url = ''
    #addDir('[COLOR cyan]Main Menu[/COLOR]',url , 'SectionMenu', iconSite, fanartSite, desc,isFolder=True)
    set_view('movies',view_mode=addst('movies-view')); 
    eod()


def SectionTVShows_Epi(url):
    if UseAccount==True:
                DayLoggedIn=addst('dayloggedin','')
                DayLoggedInNew=str(datetime.date.today().day)
                if (isFile(CookieJarFile)==False) or (is_expired (CookieJarFile)) or (LastUsername!=AccountUsername) or (LastPassword!=AccountPassword):
                        loginurl='https://www.streamlive.to/loginJson.php'
                        GetLogin=nURL(loginurl,method='post',headers={'Referer':doMain},form_data={'username':AccountUsername,'password':AccountPassword,'submit':'Login'},cookie_file=CookieJarFile,save_cookie=True)
                        addstv('dayloggedin',DayLoggedInNew)
                        addstv('last_username',AccountUsername)
                        addstv('last_password',AccountPassword)
                        print("usr " + AccountUsername)
                        print("pass " + AccountPassword)

                cookie_file=CookieJarFile
                cj = cookielib.LWPCookieJar()
                cj.load(cookie_file, ignore_discard=True)
                source = requests.get(url,cookies=cj).text#;print source
                part = re.findall('(?s)"playing-on(.*?)</div',source)[0]
                link = re.compile('(?s)href="(.*?)".*?style=.*?>(.*?)<').findall(part)
    else:
                source = nURL(url) 
                part = re.findall('(?s)"playing-on(.*?)</div',source)[0]
                link = re.compile('(?s)href="(.*?)".*?style=.*?>(.*?)<').findall(part)

    for url,name in link:
                thumb = '' 
                addDir('[COLOR cyan]%s[/COLOR]'%name, url, 'Movie_Play', iconSite, thumb, '',isFolder=False)
    set_view('movies',view_mode=addst('movies-view'));
    eod(); 

def SectionFavorite(np):
    if np == '' : np = 1
    url = 'https://www.streamlive.to/channels_favorite.php?p=%s'%np
    if UseAccount==True:
                DayLoggedIn=addst('dayloggedin','')
                DayLoggedInNew=str(datetime.date.today().day)
                if (isFile(CookieJarFile)==False) or (is_expired (CookieJarFile)) or (LastUsername!=AccountUsername) or (LastPassword!=AccountPassword):
                        loginurl='https://www.streamlive.to/loginJson.php'
                        GetLogin=nURL(loginurl,method='post',headers={'Referer':doMain},form_data={'username':AccountUsername,'password':AccountPassword,'submit':'Login'},cookie_file=CookieJarFile,save_cookie=True)
                        addstv('dayloggedin',DayLoggedInNew)
                        addstv('last_username',AccountUsername)
                        addstv('last_password',AccountPassword)
                        print("usr " + AccountUsername)
                        print("pass " + AccountPassword)

                cookie_file=CookieJarFile
                cj = cookielib.LWPCookieJar()
                cj.load(cookie_file, ignore_discard=True)
                source = requests.get(url,cookies=cj).text#

                link = re.findall('(?s)class="ml-item.*?a href="(.*?)".*?title="(.*?)".*?src="(.*?)"',source)

    else:
                source = nURL(url) 
    source = nolines(messupText(source.replace("&nbsp;",""),True,True));
    part = re.findall('(?s)class="pagination"(.*?)</ul',source)[0];print(part)
    part2 = re.findall('(?s)data-page="(\d+)"',part)
    if len(part2) == 0 : npage = 1
    else : npage = max(part2)

    link = re.findall('(?s)class="ml-item.*?a href="(.*?)".*?title="(.*?)".*?src="(.*?)"',source)
    for url,name,thum in link:
                thumb = thum
                #name = name.encode('utf-8','ignore')
                ItemCount=len(link)
                #addDir('[COLOR cyan]%s[/COLOR]'%name, url, 'iLivePlay', iconSite, thumb, '',isFolder=False)
                pars={'mode':'iLivePlay','site':'','section':'','title':name,'url':url,'fanart':thumb,'img':thumb,'link':'99'}; 
                PlotD=cFL("[CR]Language: "+''+"[CR]Category: "+''+"[CR]Viewers: "+''+"[CR]TotalViews: "+'',"tan"); 
                if True: _addon.add_directory(pars,{'title':'[COLOR cyan]%s[/COLOR]'%name,'plot':PlotD},is_folder=False,fanart=thumb,img=thumb,total_items=ItemCount)
                #except: pass
    if int(np) + 1 <= int(npage) :
            url = str(int(np) + 1)
            desc = ''
            addDir('[COLOR cyan]Next >>>[/COLOR]',url , 'Favorite', iconSite, fanartSite, desc,isFolder=True)

    set_view('movies',view_mode=addst('movies-view')); 
    eod(); 

def SectionMyDVR(np):
    if np == '' : np = 1
    url = 'https://www.streamlive.to/user_recordings?p=%s'%np
    if UseAccount==True:
                DayLoggedIn=addst('dayloggedin','')
                DayLoggedInNew=str(datetime.date.today().day)
                if (isFile(CookieJarFile)==False) or (is_expired (CookieJarFile)) or (LastUsername!=AccountUsername) or (LastPassword!=AccountPassword):
                        loginurl='https://www.streamlive.to/loginJson.php'
                        GetLogin=nURL(loginurl,method='post',headers={'Referer':doMain},form_data={'username':AccountUsername,'password':AccountPassword,'submit':'Login'},cookie_file=CookieJarFile,save_cookie=True)
                        addstv('dayloggedin',DayLoggedInNew)
                        addstv('last_username',AccountUsername)
                        addstv('last_password',AccountPassword)
                        print("usr " + AccountUsername)
                        print("pass " + AccountPassword)

                cookie_file=CookieJarFile
                cj = cookielib.LWPCookieJar()
                cj.load(cookie_file, ignore_discard=True)
                source = requests.get(url,cookies=cj).text#
    else:
                source = nURL(url) 

    source = nolines(messupText(source.replace("&nbsp;",""),True,True));
    part = re.findall('(?s)Page(.*?)</td',source)[0]
    part2 = re.findall('(?s)\p=(\d+)"',part)
    if len(part2) == 0 : npage = 1
    else : npage = max(part2)

    patron = re.compile('(?s)<h3>Completed Recordings(.*?)</table>')
    page = patron.findall(source)[0]
    link = part = re.findall('(?s)scope="row".*?<td>(.*?)\s?<.*?<td>.*?<.*?<td>(.*?)\s?<.*?href="(.*?progn=(.*?))"',page);

    for name2, name3, url, name1 in link:
                thumb = ''
                #name = name.encode('utf-8','ignore')
                ItemCount=len(link)
                if 'http' not in url : url = 'https://www.streamlive.to/'+ url
                name3 = name3.replace('2019','').replace(' ','')
                name3 = name3.split(',')[0][:5]+' '+name3.split(',')[1]
                name1 = name1[:32]
                #if len(name2) > 10 : name2 = name2.replace('(HD)','')
                addDir('[COLOR cyan]%s[/COLOR] %s %s'%(name1.strip(),name2.strip(),name3.strip()), url, 'Movie_Play', thumb, thumb, '',isFolder=False)
    if int(np) + 1 <= int(npage) :
                url = str(int(np) + 1)
                desc = ''
                addDir('[COLOR cyan]Next >>>[/COLOR]',url , 'MyDVR', iconSite, fanartSite, '',isFolder=True)

    set_view('movies',view_mode=addst('movies-view')); 
    eod(); 


def iLiveBrowse(channel='',iLive_Sort='',iLive_Language='',search=''):
	if len(iLive_Sort)==0: iLive_Sort="0"
	ApiLiveDomain=addst('DefaultApiLiveList','Default'); 
	headers={'Referer':doMain}; 
	if len(search) > 0: tUrl="%schannels/?q=%s"%(doMain,search)
	else: tUrl=doMain+"channels/"+channel.replace(" ","%20")+"?sort="+iLive_Sort+"&lang="+iLive_Language; 
	
	deb("url",tUrl); 
	html=nURL(tUrl,headers=headers); deb("length of first page",str(len(html))); 
	if '<p align="center" class="pages"><strong>Page: </strong>' in html:
		phtml=html.split('<p align="center" class="pages"><strong>Page: </strong>')[1].split('</span></p>')[0]; deb("length of phtml",str(len(phtml))); 
		try: ppages=re.compile('<a href="(http(?:s)?://www.(?:streamlive.to)?/channels/.+?)">\s*(\d+)\s*</a').findall(phtml.replace('</a>','</a\n\r>'))
		except: ppages=[]
		deb("number of pages",str(len(ppages)+1)); debob(ppages); 
		dialogWait=xbmcgui.DialogProgress(); loaded=1; ptotal=len(ppages)+1; ret=dialogWait.create('Please wait...'); 
		percent=(loaded * 100)/ptotal; remaining_display='[B]Page '+str(loaded)+' of '+str(ptotal)+'[/B].'; dialogWait.update(percent,'[B]Loading Pages...[/B]',remaining_display); 
		for (ppage,pname) in ppages: 
			time.sleep(1); html+=nURL(ppage.replace(" ","%20")); 
			loaded=loaded+1; percent=(loaded * 100)/ptotal; remaining_display='[B]Page '+str(loaded)+' of '+str(ptotal)+'[/B].'; dialogWait.update(percent,'[B]Loading Pages...[/B]',remaining_display); 
		dialogWait.close(); del dialogWait
	html=nolines(messupText(html.replace("&nbsp;",""),True,True)); 
	deb("length of all pages",str(len(html))); 
	s='<noscript><img width="\d+" height="\d+" src="(\D+://snapshots.(?:streamlive.to)?/snapshots/[0-9a-zA-Z]+_snapshot.jpg)" alt=".+?"\s*/></noscript>\s*</a>\s*'; 
	s+='<a href="(\D+://www.(?:streamlive.to)?/(?:view-kodi|view-channel|view-kodi)?/\d+/.+?)"><strong>\s*(.+?)\s*</strong></a><br/>\s*'; 
	s+='<span class="viewers">([0-9\,]+)</span>\s*'; 
	s+='<span class="totalviews">([0-9\,]+)</span><br/>\s*'; 
	s+='<a href="\D+://www.(?:streamlive.to)?/channels/.+?">([A-Za-z0-9\s]*)</a>\s*'; 
	s+='<a href="\D+://www.(?:streamlive.to)?/channels\?lang=\d*">([A-Za-z0-9\s]*)</a>\s*</li'; 
	match=re.compile(s).findall(html); ItemCount=len(match); debob(match); 
	for thumb,url,name,iViewers,iTotalViews,Category,lang in match:
		unCacheAnImage(thumb); 
		pars={'mode':'iLivePlay','site':site,'section':section,'title':name,'url':url,'fanart':thumb,'img':thumb,'link':'99'}; 
		PlotD=cFL("[CR]Language: "+lang+"[CR]Category: "+Category+"[CR]Viewers: "+iViewers+"[CR]TotalViews: "+iTotalViews,"tan"); 
		try: _addon.add_directory(pars,{'title':name+'  ['+cFL(lang,colors['6'])+']','plot':PlotD},is_folder=False,fanart=thumb,img=thumb,total_items=ItemCount)
		except: pass
	set_view('movies',view_mode=addst('movies-view')); 
	eod(); 
def iLiveBrowseLIVE(channel='',iLive_Sort='',iLive_Language='',iLive_category='',search='',page=''):
	pagination_enable = True
	items_per_page = 50
	items_added = 0
	items_skipped = 0
	iLive_category=channel
	if len(iLive_Sort)==0: iLive_Sort="0"
	tUrl=doMain+"api/live-kodi.xml"; 
	deb("url",tUrl); 
	html=nURL(tUrl,headers=headers); deb("length of remote xml",str(len(html))); 
	LocalXML=os.path.join(_addonPath,'live-kodi.xml')
	if len(html) > 20:
		try: _SaveFile(LocalXML,html)
		except: pass
	elif isFile(LocalXML):
		deb("Faild to load Remote File","Attempting to load local file."); myNote("Faild to load Remote File","Attempting to load local file."); 
		try: html=_OpenFile(LocalXML)
		except: html=''
		deb("length of local xml",str(len(html))); 
		if len(html) < 20:
			deb("Faild to load Remote File","Unable to locate local file."); myNote("Faild to load Remote File","Unable to locate local file."); 
	else: 
		deb("Faild to load Remote File","Unable to locate local file."); myNote("Faild to load Remote File","Unable to locate local file."); 
		pass
	if ('/api/' in tUrl) and ('.xml' in tUrl):
		iLive_Language=LanguageNoToNa(iLive_Language)
		debob({'iLive_Language':iLive_Language,'iLive_category':iLive_category,'search':search}); 
		if '</channels>' in html:
			html=nolines(html).split('</channels>')[0]
			if '<channels>' in html:
				html=html.split('<channels>')[1]; html=html.replace('</channel><channel>','</channel>\n\r<channel>').replace('</channel>','</channel\n\r>');
				deb('Length of HTML',str(len(html)));
				s="<channel><name>(.+?)</name><url>(http(?:s)?://(?:www.)?(?:streamlive.to)?/view-kodi/(\d+))</url><image>(http(?:s)?://snapshots.\D+.\D+/snapshots/(.+?)_snapshot.jpg)</image><category>(.+?)</category><language>(.*?)</language><views>(.*?)</views></channel"; 
				try: match=re.compile(s).findall(html); 
				except: match=[]
				ItemCount=len(match); deb('number of matches',str(ItemCount)); #debob(match); 
				if ItemCount > 0:
					match=sorted(match,key=lambda i:(i[5],i[0],i[6],i[7]),reverse=False)
					for (ChName,ChUrl,ChId,ChImg,ChImgId,ChCat,ChLang,ChViews) in match:
						#debob({'ChName':ChName,'ChUrl':ChUrl,'ChId':ChId,'ChImg':ChImg,'ChImgId':ChImgId,'ChCat':ChCat,'ChLang':ChLang,'ChViews':ChViews})
						if (len(search) > 0) and (not search.lower() in ChName.lower()): pass
						elif (len(iLive_Language) > 0) and (not iLive_Language.lower()==ChLang.lower()): pass
						elif (len(iLive_category) > 0) and (not iLive_category.lower()==ChCat.lower()): pass
						else:
							debob({'ChName':ChName,'ChUrl':ChUrl,'ChId':ChId,'ChImg':ChImg,'ChImgId':ChImgId,'ChCat':ChCat,'ChLang':ChLang,'ChViews':ChViews})
							contextMenuItems=[]; unCacheAnImage(ChImg); 
							pars={'mode':'iLivePlay','site':site,'section':section,'title':ChName,'url':ChUrl,'fanart':ChImg,'img':ChImg,'link':'99'}; 
							pars0={'mode':'iLivePlay','site':site,'section':section,'title':ChName,'url':ChUrl,'fanart':ChImg,'img':ChImg,'link':'0'}; 
							pars1={'mode':'iLivePlay','site':site,'section':section,'title':ChName,'url':ChUrl,'fanart':ChImg,'img':ChImg,'link':'1'}; 
							pars2={'mode':'iLivePlay','site':site,'section':section,'title':ChName,'url':ChUrl,'fanart':ChImg,'img':ChImg,'link':'2'}; 
							PlotD=cFL("[CR]Language: "+ChLang+"[CR]Category: "+ChCat+"[CR]Views: "+ChViews,"tan"); 
							contextMenuItems.append(('Channel Information','XBMC.Action(Info)'))
	
							contextMenuItems.append(('Play [HLS]' ,'XBMC.RunPlugin(%s)'%_addon.build_plugin_url(pars0) ))
							contextMenuItems.append(('Play [RTMP]','XBMC.RunPlugin(%s)'%_addon.build_plugin_url(pars1) ))
							contextMenuItems.append(('Play [RTSP]','XBMC.RunPlugin(%s)'%_addon.build_plugin_url(pars2) ))
							
							if pagination_enable:
								#Pagination on
								if items_added < items_per_page:
									if items_skipped <  (int(page)-1) * items_per_page:    
										items_skipped += 1
									else:
										try:
											_addon.add_directory(pars,{'title':ChName+'  ['+cFL(ChLang,colors['6'])+']','plot':PlotD},is_folder=False,fanart=ChImg,img=ChImg,total_items=items_per_page,contextmenu_items=contextMenuItems,context_replace=False)
											items_added += 1
										except: pass
								else:
									#next page
									_addon.add_directory({'channel':channel,'mode':'iLiveBrowseLIVE','site':site,'section':section,'title':iLive_category,'page':str(int(page)+1)},{'title':'Next page >>'},is_folder=True,fanart=fanartSite,img=iconSite)
									###
									set_view('movies',view_mode=addst('movies-view')); 
									eod();
									return
							else:
								#Pagination off
								try: _addon.add_directory(pars,{'title':ChName+'  ['+cFL(ChLang,colors['6'])+']','plot':PlotD},is_folder=False,fanart=ChImg,img=ChImg,total_items=ItemCount,contextmenu_items=contextMenuItems,context_replace=False)
								except: pass
								
	else:
		### \/ Catching the rest of the pages.
		if '<p align="center" class="pages"><strong>Page: </strong>' in html:
			phtml=html.split('<p align="center" class="pages"><strong>Page: </strong>')[1].split('</span></p>')[0];
			deb("length of phtml",str(len(phtml))); 
			try: ppages=re.compile('<a href="(http(?:s)?://www.(?:streamlive.to)?/channels/.+?)">\s*(\d+)\s*</a>').findall(phtml)
			except: ppages=[]
			deb("number of pages",str(len(ppages)+1)); debob(ppages); 
			dialogWait=xbmcgui.DialogProgress(); loaded=1; ptotal=len(ppages)+1; ret=dialogWait.create('Please wait...'); 
			percent=(loaded * 100)/ptotal; remaining_display='[B]Page '+str(loaded)+' of '+str(ptotal)+'[/B].'; dialogWait.update(percent,'[B]Loading Pages...[/B]',remaining_display); 
			for (ppage,pname) in ppages: 
				time.sleep(1); html+=nURL(ppage.replace(" ","%20")); 
				loaded=loaded+1; percent=(loaded * 100)/ptotal; remaining_display='[B]Page '+str(loaded)+' of '+str(ptotal)+'[/B].'; dialogWait.update(percent,'[B]Loading Pages...[/B]',remaining_display); 
			dialogWait.close(); del dialogWait
		### \/ Catching Items.
		html=nolines(messupText(html.replace("&nbsp;",""),True,True)); 
		deb("length of all pages",str(len(html))); 
		s='<noscript><img width="\d+" height="\d+" src="(http(?:s)?://snapshots.(?:streamlive.to)?/snapshots/[0-9a-zA-Z]+_snapshot.jpg)" alt=".+?"\s*/></noscript>\s*</a>\s*\n*\s*'; s+='<a href="(http(?:s)?://www.(?:streamlive.to)?/view-kodi/\d+/.+?)"><strong>\s*(.+?)\s*</strong></a><br/>\s*'; s+='<span class="viewers">([0-9\,]+)</span>\s*'; s+='<span class="totalviews">([0-9\,]+)</span><br/>\s*'; s+='<a href="http(?:s)?://www.(?:streamlive.to)?/channels/.+?">([A-Za-z0-9\s]*)</a>\s*'; s+='<a href="http(?:s)?://www.(?:streamlive.to)?/channels\?lang=\d*">([A-Za-z0-9\s]*)</a>\s*</li>'; 
		#debob(html); 
		match=re.compile(s).findall(html); ItemCount=len(match); 
		debob(match); 
                
		for thumb,url,name,iViewers,iTotalViews,Category,lang in match:
			unCacheAnImage(thumb); 
			pars={'mode':'iLivePlay','site':site,'section':section,'title':name,'url':url,'fanart':thumb,'img':thumb}; 
			PlotD=cFL("[CR]Language: "+lang+"[CR]Category: "+Category+"[CR]Viewers: "+iViewers+"[CR]TotalViews: "+iTotalViews,"tan"); 
			#debob(pars);
			if pagination_enable:
				#Pagination on
				if items_added < items_per_page:
					if items_skipped < (int(page)-1) * items_per_page:
						items_skipped += 1
					else:
						try:
							_addon.add_directory(pars,{'title':name+'  ['+cFL(lang,colors['6'])+']','plot':PlotD},is_folder=False,fanart=thumb,img=thumb,total_items=items_per_page)
							items_added += 1
						except: pass
				else:
					#next page
					_addon.add_directory({'channel':channel,'mode':'iLiveBrowseLIVE','site':site,'section':section,'title':iLive_category,'page':str(int(page)+1)},{'title':'Next page >>'},is_folder=True,fanart=fanartSite,img=iconSite)
					###
					set_view('movies',view_mode=addst('movies-view')); 
					eod();
					return
			else:
				#Pagination off
				try: _addon.add_directory(pars,{'title':name+'  ['+cFL(lang,colors['6'])+']','plot':PlotD},is_folder=False,fanart=thumb,img=thumb,total_items=ItemCount)
				except: pass
	###
	set_view('movies',view_mode=addst('movies-view')); 

	eod();

def iLiveSportBrowse(channel='',iLive_Sort='',iLive_Language='',iLive_category='',search=''):
	iLive_category=channel
	if len(iLive_Sort)==0: iLive_Sort="0"
	tUrl=doMain+"api/live-events.xml"; 
	deb("url",tUrl); 
	html=nURL(tUrl,headers=headers); deb("length of remote xml",str(len(html))); 
	LocalXML=os.path.join(_addonPath,'live-events.xml')
	root = None
	tree = None
	if len(html) > 20:
		try:
			_SaveFile(LocalXML,html)
		except:
			deb("Failed to load Remote File","Attempting to load local file."); myNote("Failed to save Remote File","Attempting to load local file."); 
			raise
	if isFile(LocalXML):
		try:
			tree = ElementTree()
			tree.parse(LocalXML)
			root = tree.getroot()
		except:
			pass
		if root is None:
			deb("Failed to load Remote File","Unable to locate local file."); myNote("Failed to load Remote File","Unable to locate local file."); 
	try:
		root_tag = root.tag
	except StandardError:
		root_tag = None
	if root_tag == 'events':
		events = []
		for event in tree.findall('event'):
			ev = {}
			try:
				name = event.find('name').text.encode('utf-8')
				starts = event.find('starts').text
				teams = event.find('teams').text.encode('utf-8')
				channels = event.find('channels')
			except StandardError:
				continue
			format_dt =  '%b %d, %Y %I:%M %p'
			try:
				start_dt = datetime.datetime.strptime(starts, format_dt)
			except TypeError:
				# workaround http://forum.kodi.tv/showthread.php?tid=112916
				start_dt = datetime.datetime.fromtimestamp(
						time.mktime(time.strptime(starts, format_dt))
						)
			ends = event.find('ends').text
			try:
				end_dt = datetime.datetime.strptime(ends, format_dt)
			except TypeError:
				# workaround http://forum.kodi.tv/showthread.php?tid=112916
				end_dt = datetime.datetime.fromtimestamp(
						time.mktime(time.strptime(ends, format_dt))
						)
			ev['start_time'] = start_dt
			ev['end_time'] = end_dt
			ev['title'] = ("{start}: {event_name} | {event_teams}".format(
							start=start_dt.strftime("(%b %d) %I:%M %p"), event_name=name, event_teams=teams)
							)
			ev['channels'] = []
			events.append(ev)
			curname = None
			for node in channels.getchildren():
				if node.tag == 'name':
					chan_name = node.text.encode('utf-8')
				elif node.tag == 'link':
					item = {}
					link = node.text
					reg_link = re.search(r'http://(?:www.)?(?:streamlive.to)?/[^\/]+/(\d+)/', link)
					if not reg_link:
						continue
					item['id'] = reg_link.groups()[0]
					item['url'] = link
					item['name'] = chan_name
					ev['channels'].append(item)
		ItemCount = sum(map(lambda ev: len(ev['channels']) or 1, events))
		for ev in sorted(events, key=lambda e: e['start_time']):
			_addon.add_directory({'mode': 'Dummy', 'site': site, 'section':
				section, 'title': ev['title']}, {'title': ev['title']},
				total_items=ItemCount, context_replace=False)
			if not ev['channels']:
				_addon.add_directory({'mode': 'Dummy', 'site': site, 'section':
					section, 'title': 'No channels available yet.'},
					{'title': 'No channels available yet.'},
					total_items=ItemCount, context_replace=False)
			for ch in ev['channels']:
				contextMenuItems=[];
				pars={'mode':'iLivePlay','site':site,'section':section,'title':ch['name'],'url':ch['url'],'link':'99'}; 
				pars0={'mode':'iLivePlay','site':site,'section':section,'title':ch['name'],'url':ch['url'],'link':'0'}; 
				PlotD=cFL(""); 
				contextMenuItems.append(('Channel Information','XBMC.Action(Info)'))
				contextMenuItems.append(('Play [HLS]' ,'XBMC.RunPlugin(%s)'%_addon.build_plugin_url(pars0) ))
				display_title = cFL(indL(ch['name']),colors['6'])
				try:
					_addon.add_item(pars,{'title':display_title,'plot':PlotD},total_items=ItemCount,contextmenu_items=contextMenuItems,context_replace=False)
				except Exception:
					raise
					continue
	else: 
		# pass
		deb("Faild to load Remote File","Unable to locate local file."); myNote("Failed to load Remote File", "Unable to locate local file."); 
	###
	set_view('movies',view_mode=addst('movies-view')); 
	#set_view('tvshows',view_mode=addst('tvshows-view')); 
	#set_view('list',view_mode=addst('default-view')); 
	eod(); 
def SSortSet(SSort): addstv("iLive_Sort",SSort); eod(); DoA("Back"); 
def SSortMenu():
	sC1='section'; sC2='live'; iLL='SSortSet'; fS=fanartSite; iS=iconSite; BB=[]; 
	BB.append(("0","Default")); BB.append(("1","Current Viewers")); BB.append(("2","Total Views")); 
	for (ssort,name) in BB:
		_addon.add_directory({'sort':ssort,'mode':iLL,'site':site,sC1:sC2,'title':name},{'title':cFL_(name,colors['6'])},is_folder=True,fanart=fS,img=iS); 
	set_view('list',view_mode=addst('default-view')); eod(); 
def LanguageNoToNa(n='',a=''):
	n=str(n).lower()
	if n=='': n=addst("iLive_Language")
	if  (n=='') or (n=='all'): a=''
	elif n=='1': a='English'
	elif n=='2': a='Spanish'
	elif n=='3': a='Portuguese'
	elif n=='4': a='French'
	elif n=='5': a='German'
	elif n=='6': a='Russian'
	elif n=='7': a='Vietnamese'
	elif n=='8': a='Italian'
	elif n=='9': a='Filipino'
	elif n=='10': a='Thai'
	elif n=='11': a='Chinese'
	elif n=='12': a='Indian'
	elif n=='13': a='Japanese'
	elif n=='14': a='Greek'
	elif n=='15': a='Dutch'
	elif n=='16': a='Swedish'
	elif n=='17': a='Unidentified'
	elif n=='18': a='Korean'
	elif n=='19': a='Brazilian'
	elif n=='20': a='Indian'
	elif n=='21': a='Romanian'
	return a
def LanguageSet(Language): addstv("iLive_Language",Language); eod(); DoA("Back"); 
def LanguageMenu():
	sC1='section'; sC2='live'; iLL='LanguageSet'; fS=fanartSite; iS=iconSite; BB=[]; 
	BB.append(("","All")); BB.append(("1","English")); BB.append(("2","Spanish")); BB.append(("3","Portuguese")); BB.append(("4","French")); BB.append(("5","German")); BB.append(("6","Russian")); BB.append(("7","Vietnamese")); BB.append(("8","Italian")); BB.append(("9","Filipino")); BB.append(("10","Thai")); BB.append(("11","Chinese")); BB.append(("12","Indian")); BB.append(("13","Japanese")); BB.append(("14","Greek")); BB.append(("15","Dutch")); BB.append(("16","Swedish")); BB.append(("17","Unidentified")); BB.append(("18","Korean")); BB.append(("19","Brazilian")); BB.append(("20","Indian")); BB.append(("21","Romanian")); 
	for (language,name) in BB:
		_addon.add_directory({'language':language,'mode':iLL,'site':site,sC1:sC2,'title':name},{'title':cFL_(name,colors['6'])},is_folder=True,fanart=fS,img=iS); 
	set_view('list',view_mode=addst('default-view')); eod(); 
def SectionMenu1(): #(site):
	sC1='section'; sC2='live'; iLL='iLiveList'; fS=fanartSite; iS=iconSite; 
	_addon.add_directory({'mode':'LanguageMenu','site':site,sC1:sC2},{'title':'* '+cFL_("Language",colors['6'])},is_folder=True,fanart=fS,img=iS); 
	_addon.add_directory({'mode':'SSortMenu','site':site,sC1:sC2},{'title':'* '+cFL_("Sort By",colors['6'])},is_folder=True,fanart=fS,img=iS); 
	###
	BB=[]; 
	BB.append(("","All")); BB.append(("Movies","Movies")); BB.append(("Entertainment","Entertainment")); BB.append(("Live Sport","Live Sport")); 
	BB.append(("Animation","Animation")); BB.append(("UK","UK")); BB.append(("Canada","Canada")); 
	BB.append(("General","General")); BB.append(("News","News")); BB.append(("Music","Music")); 
	BB.append(("Mobile","Mobile")); BB.append(("Family","Family")); BB.append(("Religion","Religion")); 
	BB.append(("Radio","Radio")); 
	for (channel,name) in BB: _addon.add_directory({'channel':channel,'mode':'iLiveBrowse','site':site,sC1:sC2,'title':name},{'title':cFL_(name,colors['6'])},is_folder=True,fanart=fS,img=iS); 

	_addon.add_directory({'mode':'Search','site':site},{'title':cFL_('Search',colors['6'])},is_folder=True,fanart=fS,img=iS)
	_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	#
	set_view('list',view_mode=addst('default-view')); eod()
def SectionMenu2(): #(site):
	sC1='section'; sC2='live'; iLL='iLiveList'; fS=fanartSite; iS=iconSite; 
	_addon.add_directory({'mode':'LanguageMenu','site':site,sC1:sC2},{'title':'* '+cFL_("Set Language",colors['6'])},is_folder=True,fanart=fS,img=iS); 
	#_addon.add_directory({'mode':'SSortMenu','site':site,sC1:sC2},{'title':'* '+cFL_("Sort By",colors['6'])},is_folder=True,fanart=fS,img=iS); 
	###
	BB=[]; 
	BB.append(("","All")); BB.append(("Movies","Movies")); BB.append(("Entertainment","Entertainment")); BB.append(("Live Sport","Live Sport")); 
	BB.append(("Animation","Animation")); BB.append(("UK","UK")); BB.append(("Canada","Canada")); 
	BB.append(("General","General")); BB.append(("News","News")); BB.append(("Music","Music")); 
	BB.append(("Mobile","Mobile")); BB.append(("Family","Family")); BB.append(("Religion","Religion")); 
	BB.append(("Radio","Radio")); 
	for (channel,name) in BB: _addon.add_directory({'channel':channel,'mode':'iLiveBrowseLIVE','site':site,sC1:sC2,'title':name,'page':'1'},{'title':cFL_(name,colors['6'])},is_folder=True,fanart=fS,img=iS); 
	###
	###
	_addon.add_directory({'mode':'SearchN','site':site},{'title':cFL_('Search',colors['6'])},is_folder=True,fanart=fS,img=iS)
	set_view('list',view_mode=addst('default-view')); eod()

def SectionMenu(): #(site):
	sC1='section'; sC2='live'; iLL='iLiveList'; fS=fanartSite; iS=iconSite; 
	_addon.add_directory({'mode':'SectionMenu0','site':site,sC1:sC2},{'title':'* '+cFL_("Streamlive.to Live TV Live Sport",colors['6'])},is_folder=True,fanart=fS,img=iS); 
	#_addon.add_directory({'mode':'#','site':site,sC1:sC2},{'title':'* '+cFL_("TV Guide (coming soon)",colors['6'])},is_folder=True,fanart=fS,img=iS); 
	_addon.add_directory({'mode':'Movies10_Movies','site':site,sC1:sC2},{'title':'* '+cFL_("Movies10.to Movies",colors['6'])},is_folder=True,fanart=fS,img=iS); 
	#_addon.add_directory({'mode':'About','site':site},{'title':cFL_('About',colors['9'])},is_folder=False,fanart=fanartSite,img='http://i.imgur.com/0h78x5V.png') # iconSite
	_addon.add_directory({'mode':'Movies10_TVShows','site':site,sC1:sC2},{'title':'* '+cFL_("Movies10.to TV Shows",colors['6'])},is_folder=True,fanart=fS,img=iS); 

	_addon.add_directory({'mode':'MyDVR','site':site,sC1:sC2},{'title':'* '+cFL_("My DVR",colors['6'])},is_folder=True,fanart=fS,img=iS); 
	_addon.add_directory({'mode':'Favorite','site':site,sC1:sC2},{'title':'* '+cFL_("Favorite Live Channels",colors['6'])},is_folder=True,fanart=fS,img=iS); 
	_addon.add_directory({'mode':'SearchTITLE','site':site,sC1:sC2},{'title':'* '+cFL_("Search ",colors['6'])},is_folder=True,fanart=fS,img=iS); 

	_addon.add_directory({'mode':'OpenSettings'},{'title':'* '+cFL_("Open Settings",colors['6'])},is_folder=True); 

	set_view('list',view_mode=addst('default-view')); eod()

def SectionMenu0(): #(site):
	sC1='section'; sC2='live'; iLL='iLiveList'; fS=fanartSite; iS=iconSite; 
	_addon.add_directory({'mode':'SectionMenu2','site':site,sC1:sC2},{'title':'* '+cFL_("Live TV",colors['6'])},is_folder=True,fanart=fS,img=iS); 
	#_addon.add_directory({'mode':'#','site':site,sC1:sC2},{'title':'* '+cFL_("TV Guide (coming soon)",colors['6'])},is_folder=True,fanart=fS,img=iS); 
	_addon.add_directory({'mode':'iLiveSportBrowse','site':site,sC1:sC2},{'title':'* '+cFL_("Live Sport Schedule Today. US Eastern Time",colors['6'])},is_folder=True,fanart=fS,img=iS); 
	set_view('list',view_mode=addst('default-view')); eod()

### ############################################################################################################
### ############################################################################################################
def mode_subcheck(mode='',site='',section='',url=''):
	deb('mode',mode); 
	if (mode=='SectionMenu'):		SectionMenu()
	elif (mode=='SectionMenu0'):	SectionMenu0()
	elif (mode=='Series_Epi'): SectionTVShows_Epi(url)
	elif (mode=='Movies10_Movies'):	BrowseMovie(url)
	elif (mode=='Movies10_TVShows'): SectionTVShows(url)
	elif (mode=='Movie_Play'):      play_url(url)        
	elif (mode=='Favorite'): SectionFavorite(url)
	elif (mode=='MyDVR'): SectionMyDVR(url)

	elif (mode=='SectionMenu1'):	SectionMenu1()
	elif (mode=='SectionMenu2'):	SectionMenu2()
	elif (mode=='') or (mode=='main') or (mode=='MainMenu'): SectionMenu()
	elif (mode=='SubMenu'):				SubMenu()
	elif (mode=='About'):				About()
	#elif (mode=='iLiveList'):		iLiveList(addpr('title',''))
	elif (mode=='iLivePlay'):		iLivePlay(addpr('title',''),url,thumbnail,LinkNo=addpr('link',''))
	elif (mode=='LanguageSet'):		LanguageSet(addpr('language',''))
	elif (mode=='LanguageMenu'):	LanguageMenu()
	elif (mode=='SSortSet'):			SSortSet(addpr('sort',''))
	elif (mode=='SSortMenu'):		SSortMenu()
	elif (mode=='iLiveBrowse'):		iLiveBrowse(addpr('channel',''),addst('iLive_Sort',''),addst('iLive_Language',''))
	elif (mode=='iLiveSportBrowse'):	iLiveSportBrowse()
	elif (mode=='iLiveBrowseLIVE'):		iLiveBrowseLIVE(channel=addpr('channel',''),iLive_Sort=addst('iLive_Sort',''),iLive_Language=addst('iLive_Language',''),iLive_category=addpr('category',''),search=addpr('search',''),page=addpr('page',''))
	elif (mode=='Settings'):			_addon.addon.openSettings() # Another method: _plugin.openSettings() ## Settings for this addon.
	elif (mode=='TextBoxFile'):		TextBox2().load_file(url,addpr('title','')); #eod()
	elif (mode=='TextBoxUrl'):		TextBox2().load_url(url,addpr('title','')); #eod()
	elif (mode=='Search'):				DoSearch(addpr('title',''))
	elif (mode=='SearchTITLE'):                   SearchTITLE(addpr('title',''))
	elif (mode=='SearchN'):				DoSearchLIVE(addpr('title',''))
	elif (mode=='OpenSettings'):			xbmcaddon.Addon().openSettings()
	elif (mode == 'Dummy'):pass
	else: myNote(header='Site:  "'+site+'"',msg=mode+' (mode) not found.'); import mMain
	#

mode_subcheck(addpr('mode',''),addpr('site',''),addpr('section',''),addpr('url',''))
### ############################################################################################################
### ############################################################################################################
