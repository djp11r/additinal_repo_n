def SectionMenu2(): #(site):
	sC1='section'; sC2='live'; iLL='iLiveList'; fS=fanartSite; iS=iconSite; 
	_addon.add_directory({'mode':'LanguageMenu','site':site,sC1:sC2},{'title':'* '+cFL_("Set Language",colors['6'])},is_folder=True,fanart=fS,img=iS); 
	#_addon.add_directory({'mode':'SSortMenu','site':site,sC1:sC2},{'title':'* '+cFL_("Sort By",colors['6'])},is_folder=True,fanart=fS,img=iS); 
	###
	BB=[]; 
	BB.append(("","All")); BB.append(("Movies","Movies")); BB.append(("Entertainment","Entertainment")); BB.append(("Live Sport","Live Sport")); 
	BB.append(("Animation","Animation")); BB.append(("Lifecaster","Lifecaster")); BB.append(("Gaming","Gaming")); 
	BB.append(("General","General")); BB.append(("News","News")); BB.append(("Music","Music")); 
	BB.append(("Mobile","Mobile")); BB.append(("Family","Family")); BB.append(("Religion","Religion")); 
	BB.append(("Radio","Radio")); BB.append(("Canada","Canada")); 
