import ctypes
import os
import shutil
from platform import machine
from sys import platform

import requests


def get_tls_client_binery(f_name, srcfile, destfile):
    location_url = f'https://github.com/FlorianREGAZ/Python-Tls-Client/raw/master/tls_client/dependencies/{f_name}'
    result = requests.get(location_url, stream=True)
    if result.status_code != 200: return #ok_dialog(heading=heading_str, text=error_line)
    with open(srcfile, 'wb') as f: shutil.copyfileobj(result.raw, f)
    shutil.copy(srcfile, destfile)

def get_tls_file_name():
    if platform == 'darwin':
        file_ext = '-arm64.dylib' if machine() == "arm64" else '-x86.dylib'
    elif platform in ('win32', 'cygwin'):
        file_ext = '-64.dll' if 8 == ctypes.sizeof(ctypes.c_void_p) else '-32.dll'
    else:
        if machine() == "aarch64": file_ext = '-arm64.so'
        elif "x86" in machine(): file_ext = '-x86.so'
        else: file_ext = '-amd64.so'
    return f'tls-client{file_ext}'


file_ext = get_tls_file_name()
root_dir = os.path.abspath(os.path.dirname(__file__))
ctypes_cdll_path = f'{root_dir}/dependencies/{file_ext}'
if not os.path.exists(ctypes_cdll_path):
    from xbmcvfs import translatePath
    homepath = translatePath('special://home/')
    packages_dir = os.path.join(homepath, 'addons', 'packages', file_ext)
    get_tls_client_binery(file_ext, packages_dir, translatePath(ctypes_cdll_path))
library = ctypes.cdll.LoadLibrary(ctypes_cdll_path)

# extract the exposed request function from the shared package
request = library.request
request.argtypes = [ctypes.c_char_p]
request.restype = ctypes.c_char_p

freeMemory = library.freeMemory
freeMemory.argtypes = [ctypes.c_char_p]
freeMemory.restype = ctypes.c_char_p

destroySession = library.destroySession
destroySession.argtypes = [ctypes.c_char_p]
destroySession.restype = ctypes.c_char_p
