# -*- coding: utf-8 -*-

import os
import json
import traceback
import xbmcvfs
from resources.lib.kodiutils import skipFile, get_setting, open_file_wrapper, clean_title, logger


def updateSkip(skip_option):
    # title = clean_title(title)
    # import json
    logger('updateSkip skip_option: %s' % (skip_option))
    with open_file_wrapper(skipFile, mode='r')() as file:
        json_data = json.load(file)
    for item in json_data:
        if item['title'] == skip_option.get('title'):
            item['service'] = skip_option.get('service')
            item['skip'] = skip_option.get('skip')
            item['eskip'] = skip_option.get('eskip')
            item['start'] = skip_option.get('start')
    with open_file_wrapper(skipFile, mode='w')() as file:
        json.dump(json_data, file, indent=2)

def enable_show():
    with open_file_wrapper(skipFile, mode='r')() as file:
        json_data = json.load(file)
    choices_list = []
    for item in json_data:
        if not item['service']:
            choices_list.append(item)
    # logger('len choice: %s : %s' % (len(choices_list), choices_list))
    if len(choices_list) > 0:
        try:
            from xbmcgui import Dialog
            dialog = Dialog()
            choice = dialog.select("Select to Update.", ["%s" % i['title'] for i in choices_list], autoclose=4000)
            # logger('choice: %s' % (choice))
            choice_option = choices_list[int(choice)]
            title = choices_list[int(choice)]['title']
        
            # logger('choice: type: %s choice_option: %s' % (type(choice_option), choice_option))
            choice_option.update({'service': True})
            logger('enable_show after upd: %s' % (choice_option))
            updateSkip(choice_option)
        except: logger("Error: %s" % (traceback.format_exc()))


class NotroParser():
    def __init__(self, title, logger):
        self.logger = logger
        self.skipFile = skipFile
        self.desplay_time = get_setting('default.duration')
        self.data = self.get_skip_option(title)


    def updateSkip(self, title, seconds="50", eseconds="120", start="0", service=True):
        # title = clean_title(title)
        with open_file_wrapper(self.skipFile, mode='r')() as file:
            json_data = json.load(file)
        for item in json_data:
            if item['title'] == title:
                item['service'] = service
                item['skip'] = seconds
                item['eskip'] = eseconds
                item['start'] = start
        with open_file_wrapper(self.skipFile, mode='w')() as file:
            json.dump(json_data, file, indent=2)

    def newskip(self, title, seconds=None, eseconds=None, start="0"):
        if not seconds: seconds = get_setting('default.skip')
        if not eseconds: eseconds = get_setting('default.eskip')
        newIntro = {'title': title, 'service': True, 'skip': seconds, 'start': start, 'eskip': eseconds}
        try:
            with open_file_wrapper(self.skipFile, mode='r')() as f:
                data = json.load(f)
        except:
            data = []
        data.append(newIntro)
        with open_file_wrapper(self.skipFile, mode='w')() as f:
            json.dump(data, f, indent=2)
        return newIntro

    def get_skip_option(self, title):
        # title = clean_title(title)
        try:
            with open_file_wrapper(skipFile, mode='r')() as f: data = json.load(f)
            start = [i for i in data if i['title'] == title][0]
        except: start = self.newskip(title)
        return start

    @property
    def intro(self):
        try:
            start = self.data.get('start')
            skip = int(self.desplay_time) + int(self.data.get('skip'))
            return float(start), float(skip)
        except Exception as ex:
            self.logger("intro: %s" % ex)
        return None, None

    @property
    def outro(self):
        try:
            start = self.data.get('start')
            skip = int(self.desplay_time) + int(self.data.get('eskip'))
            return float(start), float(skip)
        except Exception as ex:
            self.logger("outro: %s" % ex)
        return None, None
