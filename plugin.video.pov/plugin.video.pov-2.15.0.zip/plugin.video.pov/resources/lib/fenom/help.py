# -*- coding: utf-8 -*-
"""
	Fenom Module
"""

from fenom.control import addonPath, addonVersion, joinPath
from fenom.textviewer import TextViewerXML


def get(file):
	fenom_path = addonPath()
	fenom_version = addonVersion()
	helpFile = joinPath(fenom_path, 'lib', 'fenom', 'help', file + '.txt')
	r = open(helpFile, 'r', encoding='utf-8', errors='ignore')
	text = r.read()
	r.close()
	heading = '[B]Fenom -  v%s - %s[/B]' % (fenom_version, file)
	windows = TextViewerXML('textviewer.xml', fenom_path, heading=heading, text=text)
	windows.run()
	del windows

