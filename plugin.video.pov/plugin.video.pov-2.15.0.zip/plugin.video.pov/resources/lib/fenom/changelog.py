# -*- coding: utf-8 -*-
"""
	Fenom Module
"""

from fenom.control import addonPath, addonVersion, joinPath
from fenom.textviewer import TextViewerXML


def get():
	fenom_path = addonPath()
	fenom_version = addonVersion()
	changelogfile = joinPath(fenom_path, 'changelog.txt')
	r = open(changelogfile, 'r', encoding='utf-8', errors='ignore')
	text = r.read()
	r.close()
	heading = '[B]Fenom -  v%s - ChangeLog[/B]' % fenom_version
	windows = TextViewerXML('textviewer.xml', fenom_path, heading=heading, text=text)
	windows.run()
	del windows

