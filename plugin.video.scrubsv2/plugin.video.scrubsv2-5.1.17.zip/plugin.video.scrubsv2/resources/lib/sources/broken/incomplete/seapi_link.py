# -*- coding: UTF-8 -*-

import re
import base64
import simplejson as json
from six import ensure_text
from six.moves.urllib_parse import parse_qs, urlencode

from resources.lib.modules import client
from resources.lib.modules import client_utils
from resources.lib.modules import scrape_sources
from resources.lib.modules import source_utils
from resources.lib.modules import log_utils


class source:
    def __init__(self):
        try:
            self.results = []
            self.domains = ['seapi.link', 'streamembed.net', 'superembed.stream'] # (API, Streams, MainSite)
            self.base_link = 'https://seapi.link'
            self.search_movie_link = '/?type=imdb&id=%s&max_results=1'
            self.search_tvshow_link = '/?type=imdb&id=%s&season=%s&episode=%s&max_results=1'
        except Exception:
            #log_utils.log('__init__', 1)
            return


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'aliases': aliases, 'year': year}
            url = urlencode(url)
            return url
        except:
            #log_utils.log('movie', 1)
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvshowtitle': tvshowtitle, 'aliases': aliases, 'year': year}
            url = urlencode(url)
            return url
        except:
            #log_utils.log('tvshow', 1)
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            #log_utils.log('episode', 1)
            return


    def sources(self, url, hostDict):
        try:
            if url is None:
                return self.results
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            imdb = data['imdb']
            season, episode = (data['season'], data['episode']) if 'tvshowtitle' in data else ('0', '0')
            if 'tvshowtitle' in data:
                search_url = self.base_link + self.search_tvshow_link % (imdb, season, episode)
            else:
                search_url = self.base_link + self.search_movie_link % imdb
            html = client.request(search_url)
            html = json.loads(html)
            results = html['results']
            for result in results:
                try:
                    result_host = result['server']
                    valid, host = source_utils.is_host_valid(result_host, hostDict)
                    result_qual = result['quality']
                    result_info = result['title']
                    quality, info = source_utils.get_release_quality(result_qual, result_info)
                    qual = '%s - %s' % (quality, info)
                    result_link = result['url'].replace('\/', '/').replace('///', '//')
                    self.results.append({'source': host, 'quality': quality, 'info': info, 'url': result_link, 'direct': False})
                except:
                    log_utils.log('sources', 1)
                    pass
            return self.results
        except:
            log_utils.log('sources', 1)
            return self.results


    def resolve(self, url):
        if any(x in url for x in self.domains):
            try:
                r = client.request(url)
                log_utils.log('r: ' + repr(r))
                
                i = client_utils.parseDOM(r, 'iframe', ret='src')[0]
                log_utils.log('i: ' + repr(i))
                
                p = re.findall(r'''window.atob\('(.+?)'\)''', i)[0]
                log_utils.log('p: ' + repr(p))
                
                link = base64.b64decode(p)
                log_utils.log('link1: ' + repr(link))
                
                link = ensure_text(link, errors='ignore')
                log_utils.log('link2: ' + repr(link))
                url = link.replace('\/', '/').replace('///', '//')
            except:
                log_utils.log('resolve', 1)
                pass
            return url
        else:
            return url


