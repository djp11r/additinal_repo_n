# -*- coding: utf-8 -*-

from six.moves.urllib_parse import parse_qs, urlencode

from resources.lib.modules import client
from resources.lib.modules import cleantitle
from resources.lib.modules import scrape_sources
#from resources.lib.modules import log_utils


class source:
    def __init__(self):
        try:
            self.results = []
            self.domains = ['filmxy.pw', 'filmxy.me', 'filmxy.one', 'filmxy.tv', 'filmxy.live', 'filmxy.cc']
            self.base_link = 'https://www.filmxy.pw'
        except Exception:
            #log_utils.log('__init__', 1)
            return


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            #log_utils.log('movie', 1)
            return


    def sources(self, url, hostDict):
        try:
            if url == None:
                return self.results
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = cleantitle.geturl(data['title'])
            year = data['year']
            search_url = self.base_link + '/%s-%s' % (title, year)
            html = client.scrapePage(search_url).text
            page_results = client.parseDOM(html, 'div', attrs={'class': 'video-section'})[0]
            page_urls = client.parseDOM(page_results, 'a', ret='data-player')
            for url in page_urls:
                url = client.replaceHTMLCodes(url)
                url = client.parseDOM(url, 'iframe', ret='src')[0]
                for source in scrape_sources.process(hostDict, url):
                    self.results.append(source)
            page_links = client.parseDOM(page_results, 'a', attrs={'target': '_blank'}, ret='href')
            for link in page_links:
                if any(i in link for i in ['vip-membership', 'rapidvideo.com', 'rapidvid.to', 'openload.co', 'streamango.com', 'streamcherry.com']):
                    continue
                for source in scrape_sources.process(hostDict, link):
                    self.results.append(source)
            return self.results
        except:
            #log_utils.log('sources', 1)
            return self.results


    def resolve(self, url):
        return url


