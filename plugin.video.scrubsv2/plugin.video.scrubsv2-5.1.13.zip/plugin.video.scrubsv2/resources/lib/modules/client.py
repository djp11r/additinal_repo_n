# -*- coding: utf-8 -*-

import re
import sys
import gzip
import time
import random

import six
from six.moves import urllib_request, urllib_parse, urllib_error, urllib_response, http_cookiejar
from kodi_six import xbmc, xbmcvfs
import simplejson as json
import requests

from resources.lib.modules import client_utils
from resources.lib.modules import control
from resources.lib.modules import log_utils


CERT_FILE = control.transPath('special://xbmc/system/certs/cacert.pem')

_COOKIE_HEADER = "Cookie"
_HEADER_RE = re.compile(r"^([\w\d-]+?)=(.*?)$")

UserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:97.0) Gecko/20100101 Firefox/97.0'
MobileUserAgent = 'Mozilla/5.0 (Android 10; Mobile; rv:83.0) Gecko/83.0 Firefox/83.0'

dnt_headers = {
    'User-Agent': UserAgent,
    'Accept': '*/*',
    'Accept-Encoding': 'identity;q=1, *;q=0',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'DNT': '1'
}


def _strip_url(url):
    if url.find('|') == -1:
        return (url, {})
    headers = url.split('|')
    target_url = headers.pop(0)
    out_headers = {}
    for h in headers:
        m = _HEADER_RE.findall(h)
        if not len(m):
            continue
        out_headers[m[0][0]] = urllib_parse.unquote_plus(m[0][1])
    return (target_url, out_headers)


def _url_with_headers(url, headers):
    if not len(headers.keys()):
        return url
    headers_arr = ["%s=%s" % (key, urllib_parse.quote_plus(value)) for key, value in six.iteritems(headers)]
    return "|".join([url] + headers_arr)


def _add_request_header(_request, headers):
    try:
        if six.PY2:
            scheme = _request.get_type()
            host = _request.get_host()
        else:
            scheme = urllib_parse.urlparse(_request.get_full_url()).scheme
            host = _request.host
        referer = headers.get('Referer', '') or '%s://%s/' % (scheme, host)
        _request.add_unredirected_header('Host', host)
        _request.add_unredirected_header('Referer', referer)
        for key in headers:
            _request.add_header(key, headers[key])
    except BaseException:
        return


def _get_result(response, limit=None):
    if limit == '0':
        result = response.read(224 * 1024)
    elif limit:
        result = response.read(int(limit) * 1024)
    else:
        result = response.read(5242880)
    try:
        encoding = response.info().getheader('Content-Encoding')
    except BaseException:
        encoding = None
    if encoding == 'gzip':
        result = gzip.GzipFile(fileobj=six.BytesIO(result)).read()
    return result


def _basic_request(url, headers={}, post=None, timeout='30', limit=None):
    try:
        if post is not None:
            post = post if six.PY2 else post.encode()
        request = urllib_request.Request(url, data=post)
        _add_request_header(request, headers)
        response = urllib_request.urlopen(request, timeout=int(timeout))
        return _get_result(response, limit)
    except BaseException:
        return


def strip_cookie_url(url):
    url, headers = _strip_url(url)
    if _COOKIE_HEADER in headers.keys():
        del headers[_COOKIE_HEADER]
    return _url_with_headers(url, headers)


def request(url, close=True, redirect=True, error=False, verify=True, proxy=None, post=None, headers={}, mobile=False, XHR=False, 
        limit=None, referer='', cookie=None, compression=True, output='', timeout='30', jpost=False, params=None, method=''):
    try:
        if not url:
            return
        _headers = {}
        if headers:
            _headers.update(headers)
        if _headers.get('verifypeer', '') == 'false':
            verify = False
            _headers.pop('verifypeer')
        handlers = []
        if proxy is not None:
            handlers += [urllib_request.ProxyHandler({'http': '%s' % proxy}), urllib_request.HTTPHandler]
            opener = urllib_request.build_opener(*handlers)
            opener = urllib_request.install_opener(opener)
        if params is not None:
            if isinstance(params, dict):
                params = urllib_parse.urlencode(params)
            url = url + '?' + params
        if output == 'cookie' or output == 'extended' or not close:
            cookies = http_cookiejar.LWPCookieJar()
            handlers += [urllib_request.HTTPHandler(), urllib_request.HTTPSHandler(), urllib_request.HTTPCookieProcessor(cookies)]
            opener = urllib_request.build_opener(*handlers)
            opener = urllib_request.install_opener(opener)
        if output == 'elapsed':
            start_time = time.time() * 1000
        try:
            import platform
            node = platform.uname()[1]
        except BaseException:
            node = ''
        if verify is False and sys.version_info >= (2, 7, 12):
            try:
                import ssl
                ssl_context = ssl._create_unverified_context()
                ssl._create_default_https_context = ssl._create_unverified_context
                ssl_context.set_alpn_protocols(['http/1.1'])
                handlers += [urllib_request.HTTPSHandler(context=ssl_context)]
                opener = urllib_request.build_opener(*handlers)
                opener = urllib_request.install_opener(opener)
            except BaseException:
                pass
        if verify and ((2, 7, 8) < sys.version_info < (2, 7, 12) or node == 'XboxOne'):
            try:
                import ssl
                ssl_context = ssl.create_default_context()
                ssl_context.check_hostname = False
                ssl_context.verify_mode = ssl.CERT_NONE
                ssl_context.set_alpn_protocols(['http/1.1'])
                handlers += [urllib_request.HTTPSHandler(context=ssl_context)]
                opener = urllib_request.build_opener(*handlers)
                opener = urllib_request.install_opener(opener)
            except BaseException:
                pass
        else:
            try:
                import ssl
                ssl_context = ssl.create_default_context(cafile=CERT_FILE)
                ssl_context.set_alpn_protocols(['http/1.1'])
                handlers += [urllib_request.HTTPSHandler(context=ssl_context)]
                opener = urllib_request.build_opener(*handlers)
                opener = urllib_request.install_opener(opener)
            except BaseException:
                pass
        if url.startswith('//'):
            url = 'http:' + url
        if 'User-Agent' in _headers:
            pass
        elif mobile:
            _headers['User-Agent'] = 'Mozilla/5.0 (Android 10; Mobile; rv:83.0) Gecko/83.0 Firefox/83.0'
        else:
            _headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:97.0) Gecko/20100101 Firefox/97.0'
        if 'Referer' in _headers:
            pass
        elif referer:
            _headers['Referer'] = referer
        if 'Accept-Language' not in _headers:
            _headers['Accept-Language'] = 'en-US,en'
        if 'Accept' not in _headers:
            _headers['Accept'] = '*/*'
        if 'X-Requested-With' in _headers:
            pass
        elif XHR:
            _headers['X-Requested-With'] = 'XMLHttpRequest'
        if 'Cookie' in _headers:
            pass
        elif cookie is not None:
            if isinstance(cookie, dict):
                cookie = '; '.join(['{0}={1}'.format(x, y) for x, y in six.iteritems(cookie)])
            _headers['Cookie'] = cookie
        if 'Accept-Encoding' in _headers:
            pass
        elif compression and limit is None:
            _headers['Accept-Encoding'] = 'gzip'
        if redirect is False:
            class NoRedirectHandler(urllib_request.HTTPRedirectHandler):
                def http_error_302(self, req, fp, code, msg, headers):
                    infourl = urllib_response.addinfourl(fp, headers, req.get_full_url())
                    if sys.version_info < (3, 9, 0):
                        infourl.status = code
                        infourl.code = code
                    return infourl
                http_error_300 = http_error_302
                http_error_301 = http_error_302
                http_error_303 = http_error_302
                http_error_307 = http_error_302
            opener = urllib_request.build_opener(NoRedirectHandler())
            urllib_request.install_opener(opener)
            try:
                del _headers['Referer']
            except BaseException:
                pass
        url = client_utils.byteify(url.replace(' ', '%20'))
        req = urllib_request.Request(url)
        if post is not None:
            if jpost:
                post = json.dumps(post)
                post = post.encode('utf8') if six.PY3 else post
                req = urllib_request.Request(url, post)
                req.add_header('Content-Type', 'application/json')
            else:
                if isinstance(post, dict):
                    post = client_utils.byteify(post)
                    post = urllib_parse.urlencode(post)
                if len(post) > 0:
                    post = post.encode('utf8') if six.PY3 else post
                    req = urllib_request.Request(url, data=post)
                else:
                    req.get_method = lambda: 'POST'
                    req.has_header = lambda header_name: (
                        header_name == 'Content-type'
                        # or urllib_request.Request.has_header(request, header_name)
                    )
        if limit == '0':
            req.get_method = lambda: 'HEAD'
        if method:
            req.get_method = lambda: method
        _add_request_header(req, _headers)
        try:
            response = urllib_request.urlopen(req, timeout=int(timeout))
        except urllib_error.HTTPError as e:
            response = e
            server = response.info().getheader('Server') if six.PY2 else response.info().get('Server')
            if server and response.code == 403 and "cloudflare" in server.lower():
                import ssl
                ctx = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2 if six.PY3 else ssl.PROTOCOL_TLSv1_1)
                ctx.set_alpn_protocols(['http/1.1'])
                handle = [urllib_request.HTTPSHandler(context=ctx)]
                opener = urllib_request.build_opener(*handle)
                try:
                    response = opener.open(req, timeout=int(timeout))
                except BaseException:
                    #log_utils.log('Request-HTTPError (%s): %s' % (response.code, url))
                    if not error:
                        return ''
            elif output == '':
                #log_utils.log('Request-HTTPError (%s): %s' % (response.code, url))
                if not error:
                    return ''
        except urllib_error.URLError as e:
            response = e
            if output == '':
                #log_utils.log('Request-Error (%s): %s' % (e.reason, url))
                return ''
        if output == 'cookie':
            try:
                result = '; '.join(['%s=%s' % (i.name, i.value) for i in cookies])
            except BaseException:
                pass
            if close:
                response.close()
            return result
        elif output == 'elapsed':
            result = (time.time() * 1000) - start_time
            if close:
                response.close()
            return int(result)
        elif output == 'geturl':
            result = response.url
            if close:
                response.close()
            return result
        elif output == 'headers':
            result = response.headers
            if close:
                response.close()
            return result
        elif output == 'chunk':
            try:
                content = int(response.headers['Content-Length'])
            except BaseException:
                content = (2049 * 1024)
            if content < (2048 * 1024):
                return
            result = response.read(16 * 1024)
            if close:
                response.close()
            return result
        elif output == 'file_size':
            try:
                content = int(response.headers['Content-Length'])
            except BaseException:
                content = '0'
            response.close()
            return content
        if limit == '0':
            result = response.read(1 * 1024)
        elif limit is not None:
            result = response.read(int(limit) * 1024)
        else:
            result = response.read(5242880)
        encoding = None
        text_content = False
        if response.headers.get('content-encoding', '').lower() == 'gzip':
            result = gzip.GzipFile(fileobj=six.BytesIO(result)).read()
        content_type = response.headers.get('content-type', '').lower()
        text_content = any(x in content_type for x in ['text', 'json', 'xml', 'mpegurl'])
        if 'charset=' in content_type:
            encoding = content_type.split('charset=')[-1]
        if encoding is None:
            epatterns = [r'<meta\s+http-equiv="Content-Type"\s+content="(?:.+?);\s+charset=(.+?)"', r'xml\s*version.+encoding="([^"]+)']
            for epattern in epatterns:
                epattern = epattern.encode('utf8') if six.PY3 else epattern
                r = re.search(epattern, result, re.IGNORECASE)
                if r:
                    encoding = r.group(1).decode('utf8') if six.PY3 else r.group(1)
                    break
        if encoding is None:
            r = re.search(b'^#EXT', result, re.IGNORECASE)
            if r:
                encoding = 'utf8'
        if encoding is not None:
            result = result.decode(encoding, errors='ignore')
            text_content = True
        elif text_content and encoding is None:
            result = result.decode('latin-1', errors='ignore') if six.PY3 else result
        else:
            log_utils.log('Unknown Page Encoding: ' + repr(url))
        if output == 'extended':
            try:
                response_headers = dict([(item[0].title(), item[1]) for item in list(response.info().items())])
            except BaseException:
                response_headers = response.headers
            response_url = response.url
            response_code = str(response.code)
            try:
                cookie = '; '.join(['%s=%s' % (i.name, i.value) for i in cookies])
            except BaseException:
                pass
            if close:
                response.close()
            return (result, response_code, response_headers, _headers, cookie, response_url)
        else:
            if close:
                response.close()
            return result
    except Exception as e:
        log_utils.log('Request-Error: (%s) => %s' % (str(e), url))
        #log_utils.log('request', 1)
        return


def scrapePage(url, referer=None, headers=None, post=None, cookie=None, timeout='30'):
    try:
        if not url:
            return
        url =  "https:" + url if url.startswith('//') else url
        with requests.Session() as session:
            if headers:
                session.headers.update(headers)
            if (referer and not 'Referer' in session.headers):
                session.headers.update({'Referer': referer})
            else:
                elements = urllib_parse.urlparse(url)
                base = '%s://%s' % (elements.scheme, (elements.netloc or elements.path))
                session.headers.update({'Referer': base})
            if (cookie and not 'Cookie' in session.headers): # not tested yet, just placed as a idea reminder.
                session.headers.update({'Cookie': cookie})
            if not 'User-Agent' in session.headers:
                session.headers.update({'User-Agent': UserAgent})
            if post:
                page = session.post(url, data=post, timeout=int(timeout))
            else:
                page = session.get(url, timeout=int(timeout))
            ###################################################################
            """## A ghetto fix for blockage that could probably be coded better.
            resp_code = str(page.status_code)
            resp_header = page.headers
            resp_server = resp_header['Server']
            if resp_code in ['403', '503'] and resp_server == 'cloudflare':
                #log_utils.log('scrapePage - url with cloudflare: ' + repr(url))
                url = 'https://corsproxy.io/?' + url
                if post:
                    page = session.post(url, data=post, timeout=int(timeout))
                else:
                    page = session.get(url, timeout=int(timeout))
            """
            ###################################################################
            page.encoding = 'utf-8'
            #page.raise_for_status()  # Commented out to make trakt progress option work properly again lol
        return page
    except Exception:
        #log_utils.log('scrapePage', 1)
        return


def url_ok(url): #  Old Code Saved.
    r = scrapePage(url)
    if r.status_code == 200 or r.status_code == 301:
        return True
    else:
        return False


